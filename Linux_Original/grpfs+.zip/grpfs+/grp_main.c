static const char *rcsid="$Id: grp_main.c,v 3.6 2009/10/20 08:38:18 lvs Exp $";

/*
 * ========================================================================
 * For revision number etc. see the variable `rcsid' above.
 * Revision log is at the end of file.
 * ------------------------------------------------------------------------
 * This module contains the main function of the program.
 * ========================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grp.h"
#include "grp_main.h"
#include "ccopt.h" /* contains compiler options, auto-generated on Linux */

/* Global variables: */
FTY polyx,       /* polytropic index of the configuration */
    sigma,       /* p_central/rho_central c^2 */
    lambda,      /* rho_vac/rho_central */
    coscon,      /* "true" cosmological constant Lambda */
    rhoc,        /* rho_c = central pressure of the configuration */
    keos,        /* coefficient K of the EOS */
    xg,          /* final xi guess */
    xfac,        /* extension factor */
    epsilon,     /* accuracy */
    dxsav,       /* min record interval */
    mxsav,       /* max record interval */
    **yp,        /* dependent variables store */
    *xp,         /* independent variable store */
    **d,*x;      /* pointers to matrix and vector used by pzextr and rzextr */
int kmax,        /* # of steps / max # of steps to store with -a */
    ekmax=-1,    /* store of the above for external case */
    kount,       /* true number of adapt. stepsize points, kount <= kmax */
    ikount,      /* store of the above for internal case */
    nrhs;        /* rhs() call counter */
struct {         /* characteristic skales */
    BOOL true;   /* 0 = output relative, 1 = rhoc given, 2 = K of EOS given */
    FTY lngt;    /* length skale */
    FTY mass;    /* mass skale */
    FTY ergy;    /* energy skale */
    FTY dnty;    /* mass density skale */
    FTY edny;    /* energy density skale */
    FTY prse;    /* pressure skale */
} skal;

/* Global command-line options holders: */
BOOL method=0,   /* 0 = fixed step, 1 = ad.step RK4, 2 = ad.step BS */
    iact=1;      /* 0 = batch mode, 1 <= run interactively by default */

/* Other global Boolean holders: */
BOOL iscc=0,     /* 0 = use lambda, 1 = use "true" cosmological constant */
    isx=0,       /* 0 = no extension, 1 = extend to external space */
    adbmode;     /* polytropic = 0, adiabatic = 1 */

int main(int argc, char *argv[])
{
    /* Variables and pointers: */
    int clopt;                 /* command line option variable */
    char rcs[RCSITM][RCSBUF];  /* RCS holder */
    char creator[CMDLBUF],     /* command line holder */
	*basename;

    /* push program invocation name into string 'creator';
       for the rest of command line see section 'cmd line rest' below */
    (void)strcpy(creator,argv[0]);

    /* the following code sets adbmode=1 if program invoked as grafs
       via symlink, and adbmode=0 if invoked normally as grpfs */
    if ((basename=strrchr(creator,'/')) != NULL)
	basename++;
    else
	basename=creator;
    adbmode = !strcmp(basename,CNAME_A);

    /* Command line processing: */
    while (--argc > 0 && (*++argv)[0] == '-')
	while ((clopt = *++argv[0]))
	    switch (clopt) {
		/* interactive '-i' vs. batch '-b' mode */
		case 'i':  /* '-i' causes interactive session (default) */
		    iact=2;
		    break;
		case 'b':  /* '-b' causes run in batch mode */
		    if (iact!=2) iact=0;  /* higher precedence for -i */
		    break;
		    /* fixed '-f' vs. adaptive '-a' method */
		case 'f':  /* fixed step 4th-order Runge-Kutta */
		    if (!method) method=0;  /* '-aBK' > '-f' */
		    break;
		case 'a':  /* adaptive step (default with '-K' and '-B') */
		    /* modifiers for the '-a' option */
		case 'K':  /* 5th Cash-Karp Runge-Kutta (default if '-a') */
		    if (method!=2) method=1; /* prec. of '-a' bellow '-B' */
		    break;
		case 'B':  /* Bulirsch-Stoer modified midpoint */
		    method=2;  /* '-B' of greater prec. than '-K' and '-a' */
		    break;
		default:
		    cry_err_c("unrecognized option, exiting to system",
			      clopt, 1);
		    break;
	    }
    /* now argv[0] is the first argument excluding options */

    /* We cut the string pointed by rcsid into relevant pieces. */
    /* 5 == RCSITM - 1 */
    sscanf(rcsid,"%s%s%s%s%s%s%s%s",\
	   rcs[0],rcs[0],rcs[0],rcs[1],rcs[2],rcs[3],rcs[4],rcs[5]);

    /* Now the program introduces itself politely. */
    (void)fprintf(STDMSG,"This is %s, Revision %s <%s %s> by "CAUTH"\n",\
		  basename,rcs[0],rcs[1],rcs[2]);

    /* cmd line rest */
    switch (iact) {
	case 0:
	    strcat(creator," -b");
	    break;
	case 1:
	    strcat(creator," -i");
	    break;
	case 2:
	    strcat(creator," -i");
	    break;
	default:
	    break;
    }
    switch (method) {
	case 0:
	    strcat(creator," -f");
	    break;
	case 1:
	    strcat(creator," -aK");
	    break;
	case 2:
	    strcat(creator," -aB");
	    break;
	default:
	    break;
    }

    /* Prints claim for inivalues to stderr, loading them from stdin. */
    feed_in();

    /* Dumps the header. */
    spit_header(rcs, creator, argv[0]);

    /* Self-explanatory ;-) */
    solve_ode();

    /* Keep tidy. */
    atexit(sweep);

    return (0);
}

/*
 * $Log: grp_main.c,v $
 * Revision 3.6  2009/10/20 08:38:18  lvs
 * RCS,v file: sta -> lvs
 *
 * Revision 3.5  2005/10/10 13:10:10  sta
 * bug in grp_io.c fixed
 *
 * Revision 3.4  2005/10/10 12:05:29  sta
 * ENERGYUNIT now 0, 1, 2 for backward compatibility
 *
 * Revision 3.3  2005/10/10 11:22:25  sta
 * ENERGYUNIT introduced
 *
 * Revision 3.2  2005/10/07 18:11:44  sta
 * Bug in K <-> rhoc transformation fixed
 *
 * Revision 3.1  2005/10/07 17:58:41  sta
 * bug in K <-> rhoc transformation fixed
 *
 * Revision 3.0  2005/10/07 17:34:57  sta
 * Starting revision
 *
 * Revision 2.5  2003/07/03 16:56:03  sta
 * returns 2 if theta increases
 *
 * Revision 2.4  2003/07/01 15:25:28  sta
 * Conservation release.
 * This release will be archived for future
 * development.
 *
 * Revision 2.3  2003/02/17 16:28:31  sta
 * adbmode defined as BOOL in main module
 * MAXSTP raised from 30000 up to 100000
 * misprinting of unphysical point with adaptive method fixed
 *
 * Revision 2.2  2003/02/05 19:16:13  sta
 * I/O bug fixed ('+' replaced by '#', could not reread)
 *
 * Revision 2.1  2003/02/05 18:25:51  sta
 * external extension added
 *
 * Revision 2.0  2003/01/30 20:24:26  sta
 * principal, full fledged revision
 *
 * Revision 1.6  2002-02-08 19:53:11+01  rag
 * Maintenance revision.
 *
 * Revision 1.5  2002-02-05 21:21:32+01  rag
 * Maintenance
 *
 * Revision 1.4  2002/02/05 09:33:59  rag
 * again, same as previous
 *
 * Revision 1.3  2002/02/05 09:32:30  rag
 * intermediate version; perhaps wrong!!
 *
 * Revision 1.2  2002/02/03 19:37:39  rag
 * RCS identificator changed.
 *
 * Revision 1.1  2001/10/02 10:52:02  rag
 * Initial revision
 *
 */
