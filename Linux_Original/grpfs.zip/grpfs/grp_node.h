/*
 * ========================================================================
 * $Id: grp_node.h,v 3.0 2005/10/07 17:34:57 sta Exp $
 * Revision log is at the end of file.
 * ------------------------------------------------------------------------
 * This header file contains C preprocessor directives, macros, variable
 * declarations and function prototypes specific for the corresponding
 * *.c module.  Caution: this header file is not self-contained. It will
 * fail unless the shared header file grp.h is included before this one.
 * ========================================================================
 */

#ifndef _GRP_NODE_
#define _GRP_NODE_

/* initial conditions */
#define XINIT 0.0      /* indep. variab. xi: integration starts from center */
#define THETA_INI 1.0  /* density(xi==0.0) == 1.0 x (central density) */
#define V_INI     0.0  /* mass inside zero-radius sphere(xi==0.0) == 0.0 */
#define XBAR_INI  0.0  /* proper radius(xi==0.0) == 0.0 */
#define E0_INI    0.0  /* proper energy(xi==0.0) == 0.0 */
#define E0G_INI   0.0  /* proper rest energy(xi==0.0) == 0.0 */
#define ORDEM_INI 0.0  /* ordinary embedding diagram z axis (xi==0.0) == 0.0 */
#define OPTEM_INI 0.0  /* optical embedding diagram z axis (xi==0.0) == 0.0 */

/* function solve_ode() */
#define GCOF 1.1       /* iteration safety coefficient */
#define H1SAF 1.02     /* h1/dxsav for safety */
#define H1X2SAF 0.02   /* h1/x2 for safety */
#define SAVBW 2.0      /* mxsav/dxsav: saving "bandwidth" */

/* function odeint() */
#define MAXSTP 100000  /* max number of steps (10000 -> 100000) */
#define MINALST 0.0    /* the minimum allowed stepsize */
/* max(eps,epsneg) for double and single prec., by machar */
/* #define MINALST MACHEPS */

/* for rkqs(): */
#define SAFETY 0.9
#define PGROW -0.2
#define PSHRNK -0.25
#define INCRF 5.0       /* max step increase factor */
#define ERRCON 1.89e-4  /* = (INCRF/SAFETY)^(1/PGROW) */

/* for bsstep(): */
#define KMAXX 8
#define IMAXX (KMAXX+1)
#define SAFE1 0.25
#define SAFE2 0.7
#define REDMAX 1.0e-5
#define REDMIN 0.7
#ifdef DBL_PREC
#define BTINY 1.0e-200
#else
#define BTINY 1.0e-30
#endif
#define SCALMX 0.1

#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
static FTY maxarg1,maxarg2;
#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ?\
        (maxarg1) : (maxarg2))
static FTY minarg1,minarg2;
#define FMIN(a,b) (minarg1=(a),minarg2=(b),(minarg1) < (minarg2) ?\
        (minarg1) : (minarg2))
static FTY sqrarg;
#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)

/* referencing declarations */
extern FTY *xp,**yp,**d,*x;
extern BOOL method;
extern struct {   /* characteristic scales */
    BOOL true;
    FTY lngt;
    FTY mass;
    FTY ergy;
    FTY dnty;
    FTY edny;
    FTY prse;
} skal;

/* function prototypes */
void rk4(FTY y[],FTY dydx[],int n,FTY xz,FTY h,FTY yout[],
	 void (*derivs)(const FTY, FTY [], FTY []));
void rkdumb(FTY vstart[],int nvar,FTY x1,FTY x2,int nstep,
	    void (*derivs)(const FTY,FTY [],FTY []));
void rkck(FTY y[],FTY dydx[],int n,FTY xz,FTY h,FTY yout[],FTY yerr[],
	  void (*derivs)(const FTY,FTY [],FTY []));
void rkqs(FTY y[],FTY dydx[],int n,FTY *xz,FTY htry,FTY eps,
	  FTY yscal[],FTY *hdid,FTY *hnext,
	  void (*derivs)(const FTY,FTY [],FTY []));
void odeint(FTY ystart[],int nvar,FTY x1,FTY x2,FTY eps,
	    FTY h1,FTY hmin,int *nok,int *nbad,
	    void (*derivs)(const FTY,FTY [],FTY []),
	    void (*stepper)(FTY [],FTY [],int,FTY *,FTY,FTY,FTY [],
			 FTY *,FTY *,void (*)(const FTY,FTY [],FTY [])));
void bsstep(FTY y[], FTY dydx[], int nv, FTY *xx, FTY htry,
	    FTY eps, FTY yscal[], FTY *hdid, FTY *hnext,
	    void (*derivs)(const FTY, FTY [], FTY []));
void mmid(FTY y[], FTY dydx[], int nvar, FTY xs, FTY htot,
	  int nstep, FTY yout[], void (*derivs)(const FTY, FTY[], FTY[]));
void pzextr(int iest,FTY xest,FTY yest[],FTY yz[],FTY dy[],int nv);
void rzextr(int iest,FTY xest,FTY yest[],FTY yz[],FTY dy[],int nv);
void polint(FTY xa[], FTY ya[], int n, FTY xz, FTY *y, FTY *dy);
FTY *vector(long nl, long nh);
FTY **matrix(long nrl, long nrh, long ncl, long nch);
void free_vector(FTY *v, long nl, long nh);
void free_matrix(FTY **m, long nrl, long nrh, long ncl, long nch);

#endif /* _GRP_NODE_ */

/*
 * $Log: grp_node.h,v $
 * Revision 3.0  2005/10/07 17:34:57  sta
 * Starting revision
 *
 * Revision 2.2  2003/02/17 16:28:31  sta
 * adbmode defined as BOOL in main module
 * MAXSTP raised from 30000 up to 100000
 * misprinting of unphysical point with adaptive method fixed
 *
 * Revision 2.1  2003/02/05 18:25:51  sta
 * external extension added
 *
 * Revision 2.0  2003/01/30 20:24:26  sta
 * principal, full fledged revision
 *
 * Revision 1.4  2002-02-08 19:53:11+01  rag
 * Maintenance revision.
 *
 * Revision 1.3  2002-02-05 21:21:32+01  rag
 * Maintenance
 *
 * Revision 1.2  2001/10/05 16:07:28  rag
 * hline() declaration added.
 *
 * Revision 1.1  2001/10/02 10:53:17  rag
 * Initial revision
 *
 */
