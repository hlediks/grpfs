#ifndef _CCOPT_
#define _CCOPT_
const char *ccflg="-std=c99 -pedantic -Werror -Wall -Wmissing-prototypes -Wstrict-prototypes -Wshadow -Wpointer-arith -Wcast-qual -Wcast-align -Wwrite-strings -Wnested-externs -fshort-enums -fno-common -Dinline= -O4 $(ADD_FLAGS)";
const char *ccopt="-DDBL_PREC -Wconversion -DVERBOSE -W -DENERGYUNIT=0";
const char *ccver="gcc version 4.2.1 (SUSE Linux)";
const char *ccdat="Tue Oct 20 10:45:59 CEST 2009";
const char *ccusr="lvs";
const char *cchst="gemini.loewenet";
const char *ccip="127.0.0.2 193.84.202.110";
const char *ccunm="Linux 2.6.22.19-0.3-default #1 SMP 2009-05-27 10:35:34 +0200 i686";
const char *ccdir="/home/lvs/Pool/projects/code/grpfs";
#endif /* _CCOPT_ */
