/*
 * ========================================================================
 * $Id: grp_io.c,v 3.8 2009/10/20 09:34:22 lvs Exp $
 * Revision log is at the end of file.
 * ------------------------------------------------------------------------
 * This module contains functions controlling input/output.
 * ========================================================================
 */

#include <sys/types.h>
#include <sys/utsname.h>
#include <unistd.h>
#include <pwd.h>
#ifndef __USE_POSIX2 /* popen()/pclose() prototypes in stdio.h */
#define __USE_POSIX2
#include <stdio.h>
#undef __USE_POSIX2
#else /* __USE_POSIX2 */
#include <stdio.h>
#endif /* __USE_POSIX2 */
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <string.h> /* is this necessary?? yes, it is */
#include "grp.h"
#include "grp_io.h"

void feed_in(void)
/* Prints claim on stderr and loads from stdin. */
{
    char c; /* auxiliary for scanning lambda */

    /* initialize skales regardless of mode that we're going to be in */
    skal.lngt=skal.mass=skal.ergy=skal.dnty=skal.edny=skal.prse=1.0;

    if (iact) {
#ifdef VERBOSE
	(void)fprintf(STDMSG,\
		      "ODE solvers based on (C) Numerical Recipes Software.\n");
#endif
	(void)fprintf(STDMSG,(method)?"Adaptive ":"Fixed ");
	(void)fprintf(STDMSG,"stepsize ");
	switch (method) {
	    case 0:
		(void)fprintf(STDMSG,"4th-ord. Runge-Kutta");
		break;
	    case 1:
		(void)fprintf(STDMSG,"5th-ord. Cash-Karp Runge-Kutta");
		break;
	    case 2:
		(void)fprintf(STDMSG,"Bulirsch-Stoer mdf. midpt, ");
#ifdef RAT_EXTR
		(void)fprintf(STDMSG,"rat. extr.");
#else
		(void)fprintf(STDMSG,"pol. extr.");
#endif
		break;
	    default:
		(void)fprintf(STDMSG,"unknown\n");
		break;
	}
	(void)fprintf(STDMSG,", "PREC" precision.\n");
	(void)fprintf(STDMSG,"Please feed in the quantities asked for below:\n");
	print_separator(SEPLNG);
	(void)fprintf(STDMSG,IDT1"Quantity\t\tNumer. type\tInput/Status\tEcho check\n");
	print_separator(SEPLNG);
    }

/* check magic number from stdin and from method match */
    check_magic();

/* central pressure/K of EOS: */
    if (iact) (void)fprintf(STDMSG,IDT1"rhoc|K ["RHOCUNIT"|.]\treal,if><0:true\t");
    meta_gobble();
    (void)scanf(FTF,&rhoc);
    if (rhoc>0.0) {
	skal.true=1;  /* positive: as rho_c, forces true scaling in output */
	if (iact) (void)fprintf(STDMSG,"\t\t\t\t\tTrue scale on output opted\n\t\t\t\t\tAccept |rhoc|\t%.3E\n",rhoc);
    }
    else if (rhoc<0.0) {
	skal.true=2;  /* negative: as K of EOS, forces true scaling in output*/
	keos=fabs(rhoc); /* copy abs. value of rhoc to keos */
	if (iact) (void)fprintf(STDMSG,"\t\t\t\t\tTrue scale on output opted\n\t\t\t\t\tAccepted |K|\t%.3E\n",keos);
    }
    else {
	skal.true=0;  /* zero rho_c forces dimensionless output, only lambda */
	if (iact) (void)fprintf(STDMSG,"\t\t\t\t\tDimensionless output opted\n\t\t\t\t\tno scales calculated\n\t\t\t\t\tIgnored\t\t--\n");
    }
    if (iact) print_separator(SEPLNG);
/* polyx: */
    ask_real_value(&polyx,IDT1"(p)olytropic index\treal >= 0.0\t",4,0.0,0.0,"%.3f\n");
/* sigma: */
    ask_real_value(&sigma, IDT1"(s)igma\t\treal >= 0.0\t", 4,0.0,0.0,"%.3E\n");
/* lambda or coscon: */
    if (skal.true) { /* skal.true is either 1 or 2 */
/* here we know the rhoc, polyx and sigma, and can calculate keos */
	if (skal.true==1) /* rhoc given, calculate keos */
	    keos=CMANT*CMANT*1.0E20*sigma*pow(100000.0*fabs(rhoc),-1.0/polyx);
	else /* skal.true==2, keos given, calculate rhoc */
	    rhoc=pow((CMANT*CMANT),polyx)*pow((sigma/keos),polyx)*pow(1.0E20,polyx)/100000.0;
/* here we start to treat lambda|Lambda */
	if (iact) (void)fprintf(STDMSG,IDT1"(l|L)ambda [1|"LAMBUNIT"] \treal | *real\t");
	meta_gobble();
	/* the following two lines are the medicine for a _nasty_ bug... */
	while ((c=getchar())==' ' || c=='\t') ;
	(void)ungetc(c,stdin);
	/* ...the next line read ' ' in batchmode which implies iact=1 !! */
	if ((c=getchar())=='+' || c=='-' || c=='.' || isdigit(c)) { /* scan lambda */
	    (void)ungetc(c,stdin);  /* push back +, -, . and digits */
	    (void)scanf(FTF,&lambda);
	    coscon = EIGHTPI * GC2MANT * 1.0E-23 * fabs(rhoc) * lambda;
	    if (iact) (void)fprintf(STDMSG,"\t\t\t\t\tAccepted (l)\t%.3E\n",lambda);
	}
	else { /* scan "true" cosmological constant Lambda */
	    (void)scanf(FTF,&coscon);
	    iscc = 1;
	    lambda = (1.0E23/(EIGHTPI*GC2MANT*fabs(rhoc)))*coscon;
	    if (iact) (void)fprintf(STDMSG,"\t\t\t\t\tAccepted (L)\t%.3E\n",coscon);
	}
	if (iact) print_separator(SEPLNG);
    }
    else
	ask_real_value(&lambda, IDT1"(l)ambda\t\treal\t\t", 0, 0.0,0.0,"%.3E\n");
/* final xi guess: */
    ask_real_value(&xg,IDT1"(f)inal xi guess \treal > 0.0\t",3,0.0,0.0,"%.3f\n");
/* extension factor */
    if (iact) (void)fprintf(STDMSG,IDT1"(e)xtension factor\treal,if>1:ext\t");
    meta_gobble();
    (void)scanf(FTF,&xfac);
    if (xfac>1.0) {
	isx=1;  /* extension will be used */
	if (iact) (void)fprintf(STDMSG,"\t\t\t\t\tExternal extension opted\n\t\t\t\t\tAccepted\t%.3E\n",xfac);
    }
    else {
	isx=0;  /* no extension */
	if (iact) (void)fprintf(STDMSG,"\t\t\t\t\tInternal solution only\n\t\t\t\t\tIgnored\t\t--\n");
    }
    if (iact) print_separator(SEPLNG);
    if (method) { /* adaptive stepsize */
/* max points to save: */
	ask_int_value(&kmax, IDT1"ma(x) points to save\tint 1, or >3\t", 6, 4);
/* accuracy: */
	ask_real_value(&epsilon,IDT1"(a)ccuracy\t\treal > "SMACHEP"\t",3,MACHEPS,0.0,"%.1E\n");
    }
    else { /* fixed stepsize */
/* #steps: */
	ask_int_value(&kmax, IDT1"# of s(t)eps\t\tinteger > 2\t", 4, 3);
    }

/* calculate #steps or max points to save for external portion */
    if (isx) {
	ekmax = (xfac-1.0)*kmax+1.0;
	if (ekmax < EKMAX_MIN) ekmax = EKMAX_MIN; /* no less than EKMAX_MIN */
    }

/* now calculate the scales */
    if (skal.true) {
	skal.lngt = sqrt(1.E5/(FOURPI*GC2MANT))*sqrt(sigma*(polyx+1)/fabs(rhoc));
	skal.mass = (10000.0*sigma*(polyx+1)*skal.lngt)/(GC2MANT*MSOLMANT);
	skal.ergy = (MSOLMANT*CMANT*CMANT*skal.mass)/100.0;
	skal.dnty = fabs(rhoc);
	skal.edny = (CMANT*CMANT*fabs(rhoc))/(100.0*EVMANT);
	skal.prse = (CMANT*CMANT*sigma*fabs(rhoc))/100.0;
    }

/*   if (iact) { */
/*     (void)fprintf(STDMSG,"Do you want to change your input\? y|[n]: "); */
/*     if ((c=getchar())=='y') { */
/*       (void)fprintf(STDMSG,"I wanna to do something.\n"); */
/*     } */
/*     else */
/*       (void)fprintf(STDMSG,"Nothing to do.\n"); */
/*   } */
}

void ask_int_value(int *val,const char *vdesc, const int vleg, const int vlim)
/* Ask and get integer value interactively.
   vleg: 0: get any value, 1: "<vlim" only, 2: "<=vlim" only
                           3: ">vlim" only, 4: ">=vlim" only
                           5: "=1 or >vlim",6: "=1 or >=vlim" */
{
    if (iact) (void)fprintf(STDMSG,vdesc);
    meta_gobble();

    switch (vleg) {
	case 0:
	    (void)scanf("%d",val);
	    accept_int(*val);
	    break;
	case 1:
	    do {
		(void)scanf("%d",val);
		if (*val>=vlim) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_int(*val);
	    } while (*val>=vlim);
	    break;
	case 2:
	    do {
		(void)scanf("%d",val);
		if (*val>vlim) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_int(*val);
	    } while (*val>vlim);
	    break;
	case 3:
	    do {
		(void)scanf("%d",val);
		if (*val<=vlim) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_int(*val);
	    } while (*val<=vlim);
	    break;
	case 4:
	    do {
		(void)scanf("%d",val);
		if (*val<vlim) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_int(*val);
	    } while (*val<vlim);
	    break;
	case 5:
	    do {
		(void)scanf("%d",val);
		if ((*val<=vlim) && (*val !=1)) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_int(*val);
	    } while ((*val<=vlim) && (*val !=1));
	    break;
	case 6:
	    do {
		(void)scanf("%d",val);
		if ((*val<vlim) && (*val !=1)) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_int(*val);
	    } while ((*val<vlim) && (*val !=1));
	    break;
	default:
	    (void)scanf("%d",val);
	    accept_int(*val);
	    break;
    }
}

void ask_real_value(FTY *val,const char *vdesc,const int vleg,const FTY vlim1,const FTY vlim2,const char *ffm)
/* Ask and get real value (of datatype FTY) interactively.
   vleg: 0: get any value, 1: "<vlim1" only, 2: "<=vlim1" only
                           3: ">vlim1" only, 4: ">=vlim1" only
                           5: ">vlim1,<vlim2 only"             */
{
    if (iact) (void)fprintf(STDMSG,vdesc);
    meta_gobble();

    switch (vleg) {
	case 0:
	    (void)scanf(FTF,val);
	    accept_real(ffm,*val);
	    break;
	case 1:
	    do {
		(void)scanf(FTF,val);
		if (*val>=vlim1) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_real(ffm,*val);
	    } while (*val>=vlim1);
	    break;
	case 2:
	    do {
		(void)scanf(FTF,val);
		if (*val>vlim1) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_real(ffm,*val);
	    } while (*val>vlim1);
	    break;
	case 3:
	    do {
		(void)scanf(FTF,val);
		if (*val<=vlim1) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_real(ffm,*val);
	    } while (*val<=vlim1);
	    break;
	case 4:
	    do {
		(void)scanf(FTF,val);
		if (*val<vlim1) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_real(ffm,*val);
	    } while (*val<vlim1);
	    break;
	case 5:
	    do {
		(void)scanf(FTF,val);
		if ((*val<=vlim1) || (*val>=vlim2)) { /* bad */
		    print_retry();
		}
		else /* ok */
		    accept_real(ffm,*val);
	    } while ((*val<=vlim1) || (*val>=vlim2));
	    break;
	default:
	    (void)scanf(FTF,val);
	    accept_real(ffm,*val);
	    break;
    }
}

void spit_header(char rcs[][RCSBUF], char creator[], char *title)
/* Writes output file header. */
{
    time_t t;
#ifdef VERBOSE
    FILE *read_cmd;
    char sbuffer[BUFSIZ+1];
    struct utsname uts;
    int chars_read;
    uid_t uid;
    gid_t gid;
    struct passwd *pw;
#endif
    time(&t);
#ifdef VERBOSE
    uid = getuid();
    gid = getgid();
    pw = getpwuid(uid);
#endif

    (void)printf(MNC""MAGCHR"%d\n",(int)method);

#ifdef VERBOSE
    (void)printf(MNC"\n"MNC"ID_CHART\n");

    (void)printf(HC"RunTitle: %s\n",(strlen(title)==0)?"(not supplied)":title);
    (void)printf(HC"RunAuthor: name=%s, uid=%d, gid=%d, home=%s, shell=%s\n",
		 pw->pw_name,pw->pw_uid,pw->pw_gid,pw->pw_dir,pw->pw_shell);
    (void)printf(HC"RunDate: %s",ctime(&t));
    (void)printf(HC"RunInvocation: %s\n",creator);
    (void)printf(HC"RunMode: %s\n",adbmode?"adiabatic":"polytropic");
    (void)printf(HC"RunMethod: ");
    (void)printf((method)?"Adaptive stepsize ":"Fixed stepsize ");
    switch (method) {
	case 0:
	    (void)printf("4th-ord. Runge-Kutta\n");
	    break;
	case 1:
	    (void)printf("5th-ord. Cash-Karp Runge-Kutta\n");
	    break;
	case 2:
	    (void)printf("Bulirsch-Stoer mdf. midpt, ");
#ifdef RAT_EXTR
	    (void)printf("rat. extr.\n");
#else
	    (void)printf("pol. extr.\n");
#endif
	    break;
	default:
	    (void)printf("unknown\n");
	    break;
    }

    memset(sbuffer,'\0',sizeof(sbuffer));
    if ((read_cmd=popen("hostname --fqdn","r"))!=NULL) {/* get+print fqdom */
	if ((chars_read=fread(sbuffer,sizeof(char),BUFSIZ,read_cmd)) > 0)
	    (void)printf(HC"RunHost: %s",sbuffer);
	pclose(read_cmd);
    }

    memset(sbuffer,'\0',sizeof(sbuffer));
    if ((read_cmd=popen("hostname -i","r")) != NULL) { /* get+print ip */
	if ((chars_read=fread(sbuffer,sizeof(char),BUFSIZ,read_cmd)) > 0)
	    (void)printf(HC"RunIP: %s",sbuffer);
	pclose(read_cmd);
    }

    memset(sbuffer,'\0',sizeof(sbuffer));
    if ((read_cmd=popen("pwd","r")) != NULL) { /* get+print pwd */
	if ((chars_read=fread(sbuffer,sizeof(char),BUFSIZ,read_cmd)) > 0)
	    (void)printf(HC"RunPath: %s",sbuffer);
	pclose(read_cmd);
    }

    if (uname(&uts)>=0) { /* get+print sysname, release, version, machine */
	(void)printf(HC"RunSystem: %s %s %s %s\n",
		     uts.sysname,uts.release,uts.version,uts.machine);
    }

    (void)printf(HC"CodeName: "CNAME"\n");
    (void)printf(HC"CodeRevisionAuthor: %s\n",rcs[3]);
    (void)printf(HC"CodeRevisionNo: %s\n",rcs[0]);
    (void)printf(HC"CodeRevisionDate: %s %s\n",rcs[1],rcs[2]);
    (void)printf(HC"CodeRevisionStatus: %s\n",rcs[4]);
    (void)printf(HC"CodeRevisionLocker: %s\n",rcs[5]);
    (void)printf(HC"CompilePrecision: "PREC"\n");
    if (method) {
	(void)printf(HC"CompileAccurCtrl: ");
	switch (YSCAL) {
	    case 1:
		(void)printf("relative: D=eps*(|y|+%.1E)\n",TINY);
		break;
	    case 2:
		(void)printf("absolute: D=eps*%.1f\n",YMAX);
		break;
	    case 3:
		(void)printf("abs.(y<%.1f), rel.(y>%.1f): D=eps*(max(%.1f,|y|))\n",\
			     YMAX,YMAX,YMAX);
		break;
	    case 4:
		(void)printf("accumulation-free: D=eps*(|y'*h|+%.1E)\n",TINY);
		break;
	    default:
		(void)printf("general-purp.: D=eps*(|y|+|y'*h|+%.1E)\n",TINY);
		break;
	}
    }
    (void)printf(HC"CompileNumberOfVariablesInt(Ext): %d (%d)\n",NVAR,ENVAR);
    (void)printf(HC"Compiler: %s\n",ccver);
    (void)printf(HC"CompilerOptions: %s\n",ccflg);
    (void)printf(HC"PreprocAndAddCompOptions: %s\n",ccopt);
    (void)printf(HC"CompilationDate: %s\n",ccdat);
    (void)printf(HC"CompiledByAt: %s@%s\n",ccusr,cchst);
    (void)printf(HC"CompiledAtIP: %s\n",ccip);
    (void)printf(HC"CompiledAtSystem: %s\n",ccunm);
    (void)printf(HC"CompilationDir: %s\n",ccdir);
    (void)printf(MNC"\n"MNC"INPUT\n");
#endif /* VERBOSE */

    switch (skal.true) {
	case 0: /* zero rho_c forces dimensionless output, only lambda */
	    if (adbmode) /* adiabatic */
		(void)printf(HC"central (rest mass density = rest energy density/c^2) ["DENSUNIT"]:\n"HMC);
	    else /* polytropic */
		(void)printf(HC"central (mass density = energy density/c^2) ["DENSUNIT"]:\n"HMC);
	    (void)printf("%.1f  # dimensionless output, no scales, ignored\n",rhoc);
	    break;
	case 1: /* positive: as rho_c, forces true scaling in output */
	    if (adbmode) /* adiabatic */
		(void)printf(HC"central (rest mass density = rest energy density/c^2) ["DENSUNIT"]:\n"HMC);
	    else /* polytropic */
		(void)printf(HC"central (mass density = energy density/c^2) ["DENSUNIT"]:\n"HMC);
	    (void)printf("%.6E  # true scaling on output\n",rhoc);
	    break;
	case 2: /* negative: as K of EOS, forces true scaling in output*/
	    (void)printf(HC"coefficient \"K\" of EOS ["KUNIT"]:\n"HMC);
	    (void)printf("-%.6E  # true scaling on output\n",keos);
	    break;
	default:
	    (void)fprintf(STDMSG,"unknown scaling method\n");
	    break;
    }
    if (adbmode) { /* adiabatic */
	(void)printf(HC"adiabatic index:\n"HMC"%.6E\n",polyx);
	(void)printf(HC"central (pressure/rest energy density):\n"HMC"%.6E\n",sigma);
    }
    else { /* polytropic */
	(void)printf(HC"polytropic index:\n"HMC"%.6E\n",polyx);
	(void)printf(HC"central (pressure/energy density):\n"HMC"%.6E\n",sigma);
    }
    if (iscc)
	(void)printf(HC"cosmological constant ["LAMBUNIT"]:\n"HMC"*%.6E\n",coscon);
    else {
	if (adbmode) /* adiabatic */
	    (void)printf(HC"central (vacuum energy density/rest energy density):\n"HMC"%.6E\n",lambda);
	else /* polytropic */
	    (void)printf(HC"central (vacuum energy density/energy density):\n"HMC"%.6E\n",lambda);
    }
    (void)printf(HC"final xi guess:\n"HMC"%.6E\n",xg);
    (void)printf(HC"extension factor:\n"HMC);
    (void)printf((isx)?"%.6f  # external extension on output\n":"%.1f  # internal solution only, ignored\n",xfac);
    if (method) {
	(void)printf(HC"max points internal # (external, total) to save:\n"HMC"%d # (%d,%d)\n",kmax,(isx)?ekmax:0,(isx)?kmax+ekmax:kmax);
	(void)printf(HC"accuracy (eps):\n"HMC"%.2E\n",epsilon);
    }
    else {
	(void)printf(HC"number of steps internal # (external, total):\n"HMC"%d # (%d,%d)\n",
		     kmax,(isx)?ekmax:0,(isx)?kmax+ekmax:kmax);
    }
#ifdef VERBOSE
    if (skal.true) {
	(void)printf(MNC"\n"MNC"COMPLEMENTS\n");
	if (adbmode)
	    (void)printf(HC"vacuum energy density/(cent. rest mass density * c^2):\n"HC"%.6E\n",lambda);
	else
	    (void)printf(HC"vacuum energy density/(central mass density * c^2):\n"HC"%.6E\n",lambda);
	(void)printf(HC"cosmological constant ["LAMBUNIT"]:\n"HC"%.6E\n",coscon);
	/* next line is _not_ secured for the case polyx=0.0 */
	(void)printf(HC"rhoc ["RHOCUNIT"]:\n"HC"%.6E\n",rhoc);
	(void)printf(HC"K ["KUNIT"]:\n"HC"%.6E\n",keos);
	(void)printf(MNC"\n"MNC"SCALES\n");  /* HC -> HMC later in next five?? */
	(void)printf(HC"length ["LENUNIT"]:\n"HC"%.6E\n",skal.lngt);
	(void)printf(HC"mass ["MASSUNIT"]:\n"HC"%.6E\n",skal.mass);
	(void)printf(HC"energy ["ENERUNIT"]:\n"HC"%.6E\n",skal.ergy);
	(void)printf(HC"mass density ["DENSUNIT"]:\n"HC"%.6E\n",skal.dnty);
	(void)printf(HC"energy density ["EDNYUNIT"]:\n"HC"%.6E\n",skal.edny);
	(void)printf(HC"pressure ["PRESUNIT"]:\n"HC"%.6E\n",skal.prse);
    }
    (void)printf(MNC"\n"MNC"COMPUTATION_LOG\n");
#endif
}

void print_separator(const int seplen)
/* Prints ---...--- separator on stderr. */
{
    int s=1;

    (void)fprintf(STDMSG,IDT1);
    do { (void)putc('-',STDMSG); } while ((++s)<=seplen);
    (void)putc('\n',STDMSG);
}

void print_smiley(const char *chs)
/* Prints smiley. */
{
    if (iact) (void)fprintf(STDMSG,"\t\t\t\t\t%s\t",chs);
}

void meta_gobble(void)
/* Gobble whitespace and/or comments.  Respect meta-comment CCHR+MCHR (`#!').
   Whitespace are: blanks ' ', TABs '\t', CRs '\r', LFs '\n'.   */
{
    int c;

    while ((c=getchar())=='\n'||c==' '||c=='\t'||c=='\r') ;/* Eat whitespace */
    if (c==CCHR) { /* If the 1st nonwhite is the comment char `#', then */
	if ((c=getchar())!=MCHR) { /* in case that the next char is not `!', */
	    (void)ungetc(c,stdin); /* push it back, and */
	    do { /* discard whole comment, i.e., */
		if ((c=getchar())!=MCHR) { /* skip this if next char is `!' */
		    (void)ungetc(c,stdin); /* if isn't push it back */
		    while ((c=getchar())!='\n'); /*eat until EOL and next ln.*/
		    while ((c=getchar())=='\n'||c==' '||c=='\t'||c=='\r');/* eat ws. */
		}
	    } while (c==CCHR); /* If 1st nonwhite==`#', repeat discard cmt, */
	    if (c!=MCHR) (void)ungetc(c,stdin);/* othrw.psh it bk unless `!'.*/
	}
    }
    else /* If the 1st nonwhite is not `#', push it back. */
	(void)ungetc(c,stdin);
}

void print_retry(void)
/* Prints something like "Bad, retry!!". */
{
    print_smiley("Bad, retry:\n\t\t\t\t");
}

void accept_real(const char *fm, const FTY val)
/* Prints "accepted" line for FTY. */
{
    print_smiley("Accepted");
    if (iact) {
	(void)fprintf(STDMSG,fm,val);
	print_separator(SEPLNG);
    }
}

void accept_int(const int val)
/* Prints "accepted" line for int. */
{
    print_smiley("Accepted");
    if (iact) {
	(void)fprintf(STDMSG,"%d\n",val);
	print_separator(SEPLNG);
    }
}

void spit_out(const int from, const int to, const BOOL xspit)
/* Spits output to stdin. */
{
    int k;
/* NVAR >= 2 */
    FTY tmp1,tmp2,tmp3,tmp4,tmp5,tmp10,tmp11,tmp12,tmp13,tmp14,tmp16,tmp17;
#if NVAR >= 3
    FTY tmp15;
#endif
#if NVAR >= 4
    FTY tmp6;
#endif
#if NVAR >= 5
    FTY tmp7,tmp8,tmp9;
#endif
#if NVAR >= 7
    FTY tmp18;
#endif

    if (!xspit) {
	(void)printf(MNC"\n");
	if (method)
	    (void)printf(MNC"OUTPUT %d\n",(isx)?ikount+kount-1:ikount);
	else /* 1 point is common for isx=1!! */
	    (void)printf(MNC"OUTPUT %d\n",(isx)?kmax+ekmax+1:kmax+ekmax+2);
    }
/***********************************************/
/* now we are prepared to spit out the results */
/***********************************************/
    if (!xspit) {  /******** of the internal solution ********/

	/* Obs!! Some columns have asymptotics for xi -> 0 */
	/* 1/(1+s)^n - 1, 1 - 1/(1+s)^n, 1 - (1+s)^n, (1+s)^n - 1, */
	/* respectively */

#if LOGDLESSDENS >=1
#ifdef DBL_PREC
	tmp14=log10(sigma*(polyx+1.)*xp[to]*xp[to]);
#else /* DBL_PREC */
	tmp14=(float)log10(((double)sigma)*((double)polyx+1.)*(double)xp[to]*(double)xp[to]);
#endif /* DBL_PREC */
#if NVAR >= 3
#ifdef DBL_PREC
	tmp15=log10(sigma*(polyx+1.)*yp[3][to]*yp[3][to]);
#else /* DBL_PREC */
	tmp15=(float)log10(((double)sigma)*((double)polyx+1.)*(double)yp[3][to]*(double)yp[3][to]);
#endif /* DBL_PREC */
#endif /* NVAR >= 3 */
#endif /* LOGDLESSDENS */

#if NVAR >= 5
#ifdef DBL_PREC
	tmp9=ZAPOW(1.0+sigma,polyx);
#else /* DBL_PREC */
	tmp9=(float)ZAPOW(1.0+(double)sigma,(double)polyx);
#endif /* DBL_PREC */
#endif /* NVAR >= 5 */
	tmp13=G_RR(xp[to],xp[to]*xp[to],yp[2][to],polyx,sigma,lambda);
	tmp16=ZASQRT(tmp13);

	for (k=from;k<=to;k++) {
	    tmp1=2.*sigma*(polyx+1.)*yp[2][k];
	    tmp3=1.+sigma*yp[1][k];
	    tmp10=G_RR(xp[k],xp[k]*xp[k],yp[2][k],polyx,sigma,lambda);
#if NVAR >= 4
	    tmp6=yp[4][k]-yp[2][k];
#endif
#if NVAR >= 5
	    tmp7=yp[5][k]-yp[2][k];
	    tmp8=yp[4][k]-yp[5][k];
#endif
#ifdef DBL_PREC
	    tmp2=ZAPOW(yp[1][k],polyx);
	    tmp4=ZAPOW(yp[1][k]/tmp3,polyx);
	    tmp5=ZASQRT((polyx+1.)*sigma*yp[1][k]/polyx);
	    tmp11=ZASQRT(tmp10);
	    tmp12=ZAPOW(tmp3,polyx);
#else /* DBL_PREC */
	    tmp2=(float)ZAPOW((double)(yp[1][k]),(double)polyx);
	    tmp4=(float)ZAPOW((double)(yp[1][k])/(double)tmp3,(double)polyx);
	    tmp5=(float)ZASQRT(((double)polyx+1.)*(double)sigma*(double)(yp[1][k])/(double)polyx);
	    tmp11=(float)ZASQRT((double)tmp10);
	    tmp12=(float)ZAPOW((double)tmp3,(double)polyx);
#endif /* DBL_PREC */

#if LOGDLESSDENS <=0
	    tmp14=sigma*(polyx+1.)*xp[k]*xp[k];
#if NVAR >= 3
	    tmp15=sigma*(polyx+1.)*yp[3][k]*yp[3][k];
#endif /* NVAR >= 3 */
#endif /* LOGDLESSDENS */

#ifdef DBL_PREC
	    tmp17=1./(tmp13*ZAPOW(tmp3,2.0*(polyx+1.0)));
#else /* DBL_PREC */
	    tmp17=1./(float)(tmp13*ZAPOW((double)tmp3,2.0*((double)polyx+1.0)));
#endif /* DBL_PREC */

#if NVAR >= 7
	    tmp18=1.0+sigma*(polyx+1.0)*(((2./3.)*lambda-sigma*tmp2*yp[1][k])*xp[k]*xp[k]-((xp[k]>0.0)?yp[2][k]/xp[k]:0.0))*tmp10;
#endif

    (void)printf((skal.true)?OFMT_TRUE:OFMT_DLESS,
      (method)?k-ekmax-1:k-ekmax-2, /* C1 */
      skal.lngt*xp[k],skal.lngt*xp[to],xp[k]/xp[to], /* C2, C3, C4 */
      tmp14, /* C5 */
#if NVAR <= 2
      PAD,PAD,PAD,
      PAD,
#else /* NVAR >= 3 */
      skal.lngt*yp[3][k],skal.lngt*yp[3][to],yp[3][k]/yp[3][to], /* C6,C7,C8 */
      tmp15, /* C9 */
#endif
      yp[1][k],skal.dnty*tmp2,skal.prse*tmp2*yp[1][k], /* C10, C11, C12 */
      skal.dnty*tmp4,tmp5, /* C13, C14 */
#if ENERGYUNIT <= 1
      skal.mass*yp[2][k],skal.mass*yp[2][to], /* C15, C16 */
#else /* ENERGYUNIT == 2 */
      skal.ergy*yp[2][k],skal.ergy*yp[2][to], /* C15, C16 */
#endif
      skal.lngt*tmp1,skal.lngt*2.*sigma*(polyx+1.)*yp[2][to], /* C17, C18 */
      (xp[k]==0.0)?0.0:tmp1/(2.*xp[k]), /* C19 */
      sigma*(polyx+1.)*yp[2][to]/xp[to], /* C20 */
#if NVAR <= 2
      PAD,
      PAD,
#else /* NVAR >= 3 */
      (yp[3][k]==0.0)?0.0:tmp1/(2.*yp[3][k]), /* C21 */
      sigma*(polyx+1.)*yp[2][to]/yp[3][to], /* C22 */
#endif
      (yp[2][k]==0.0)?1.0:(xp[k]*xp[k]*xp[k]/(3.*yp[2][k])), /* C23 */
      xp[to]*xp[to]*xp[to]/(3.*yp[2][to]), /* C24 */
      tmp10,tmp13, /* C25, C26 */
      tmp17,1./tmp13, /* C27, C28 */
      skal.edny*tmp2*tmp11,skal.edny*tmp4*tmp11, /* C29, C30 */
      skal.edny*tmp2*(tmp11-1.0),tmp11-1.0,tmp16-1.0, /* C31, C32, C33 */
      skal.edny*tmp2*((tmp11/tmp12)-1.0),(tmp11/tmp12)-1.0, /* C34, C35 */
      tmp16-1.0, /* C36 */
      skal.edny*tmp2*tmp11*(1.-(1./tmp12)),tmp11*(1.-(1./tmp12)), /* C37,C38 */
      tmp12*(1.0-(1.0/tmp11)),1.0-(1.0/tmp16), /* C39, C40 */
      1.0-(tmp12/tmp11),1.0-(1.0/tmp16),tmp12-1.0, /* C41, C42, C43 */
#if NVAR <= 3
      PAD,PAD,PAD,
      PAD,
      PAD,
      PAD,
#else /* NVAR >= 4 */
#if ENERGYUNIT == 1
      skal.mass*yp[4][k],skal.mass*yp[4][to],skal.mass*tmp6, /* C44,C45,C46 */
      skal.mass*(yp[4][to]-yp[2][to]), /* C47 */
#else /* ENERGYUNIT == 0 or 2 */
      skal.ergy*yp[4][k],skal.ergy*yp[4][to],skal.ergy*tmp6, /* C44,C45,C46 */
      skal.ergy*(yp[4][to]-yp[2][to]), /* C47 */
#endif
      (yp[2][k]==0.0)?0.0:tmp6/yp[2][k], /* C48 */
      (yp[4][to]-yp[2][to])/yp[2][to], /* C49 */
#endif
#if NVAR <= 4
      PAD,PAD,
      PAD,PAD,
      PAD,
      PAD,
      PAD,
      PAD,
      PAD,PAD,
      PAD,
      PAD,
      PAD,
      PAD,
      PAD,
      PAD,
#else /* NVAR >= 5 */
#if ENERGYUNIT == 1
      skal.mass*yp[5][k],skal.mass*yp[5][to], /* C50, C51 */
      skal.mass*tmp7,skal.mass*(yp[5][to]-yp[2][to]), /* C52, C53 */      
#else /* ENERGYUNIT == 0 or 2 */
      skal.ergy*yp[5][k],skal.ergy*yp[5][to], /* C50, C51 */
      skal.ergy*tmp7,skal.ergy*(yp[5][to]-yp[2][to]), /* C52, C53 */      
#endif
      (yp[2][k]==0.0)?(1.0/tmp9-1.0):tmp7/yp[2][k], /* C54 */
      (yp[5][to]-yp[2][to])/yp[2][to], /* C55 */
      (yp[5][k]==0.0)?0.0:tmp6/yp[5][k], /* C56 */
      (yp[4][to]-yp[2][to])/yp[5][to], /* C57 */
#if ENERGYUNIT == 1
      skal.mass*tmp8,skal.mass*(yp[4][to]-yp[5][to]), /* C58, C59 */
#else /* ENERGYUNIT == 0 or 2 */
      skal.ergy*tmp8,skal.ergy*(yp[4][to]-yp[5][to]), /* C58, C59 */
#endif
      (yp[2][k]==0.0)?(1.0-1.0/tmp9):tmp8/yp[2][k], /* C60 */
      (yp[4][to]-yp[5][to])/yp[2][to], /* C61 */
      (yp[5][k]==0.0)?(1.0-tmp9):tmp7/yp[5][k], /* C62 */
      (yp[5][to]-yp[2][to])/yp[5][to], /* C63 */
      (yp[5][k]==0.0)?(tmp9-1.0):tmp8/yp[5][k], /* C64 */
      (yp[4][to]-yp[5][to])/yp[5][to], /* C65 */
#endif
#if NVAR <= 5
      PAD,PAD,PAD,
#else /* NVAR >= 6 */
      yp[6][k],yp[6][to],yp[6][k]/yp[6][to], /* C66, C67, C68 */
#endif
      xp[k]/ZASQRT(tmp17),/* C69;defined if NVAR>=2 but sense only if NVAR>=7*/
#if NVAR <= 6
      PAD,PAD,
      PAD,
      PAD,
#else /* NVAR >= 7 */
      tmp16*yp[7][k],tmp16*yp[7][to], /* C70, C71 */
      (yp[7][to]!=0.)?yp[7][k]/yp[7][to]:0.0, /* C72 */
      tmp3*tmp3*(tmp10-tmp18*tmp18), /* C73: optical embeddability function */
#endif
      polyx,sigma,lambda, /* C74, C75, C76 */
      skal.lngt,skal.mass,skal.ergy,skal.dnty,skal.edny,skal.prse /*C77--C82*/
      );
	}
    }
    else {  /******** of the external solution ********/

	tmp1=2.*sigma*(polyx+1.)*yp[2][1];
#if LOGDLESSDENS >=1
#ifdef DBL_PREC
	tmp14=log10(sigma*(polyx+1.)*xp[1]*xp[1]);
#else /* DBL_PREC */
	tmp14=(float)log10(((double)sigma)*((double)polyx+1.)*(double)xp[1]*(double)xp[1]);
#endif /* DBL_PREC */
#if NVAR >= 3
#ifdef DBL_PREC
	tmp15=log10(sigma*(polyx+1.)*yp[3][1]*yp[3][1]);
#else /* DBL_PREC */
	tmp15=(float)log10(((double)sigma)*((double)polyx+1.)*(double)yp[3][1]*(double)yp[3][1]);
#endif /* DBL_PREC */
#endif /* NVAR >= 3 */
#endif /* LOGDLESSDENS */

	tmp13=G_RR(xp[1],xp[1]*xp[1],yp[2][1],polyx,sigma,lambda);
	tmp16=ZASQRT(tmp13);

	for (k=from;k<=to;k++) {
	    tmp3=1.+sigma*yp[1][k];
	    tmp10=G_RR(xp[k],xp[k]*xp[k],yp[2][1],polyx,sigma,lambda);
#ifdef DBL_PREC
	    tmp11=ZASQRT(tmp10);
#else /* DBL_PREC */
	    tmp11=(float)ZASQRT((double)tmp10);
#endif /* DBL_PREC */

#if LOGDLESSDENS <=0
	    tmp14=sigma*(polyx+1.)*xp[k]*xp[k];
#if NVAR >= 3
	    tmp15=sigma*(polyx+1.)*yp[1][k]*yp[1][k];
#endif /* NVAR >= 3 */
#endif /* LOGDLESSDENS */

#if NVAR >= 7
/* 	    tmp18=1.0+sigma*(polyx+1.0)*((2./3.)*lambda*xp[k]*xp[k]-yp[2][1]/xp[k])*tmp10; */
	    tmp18=1.0-3.0*sigma*(polyx+1.0)*yp[2][1]/xp[k];
#endif

    /* now element [1] element contains the last interior el. [kmax+ekmax+2] */
    /* it is the same as element [to]  above */
    (void)printf((skal.true)?OFMT_TRUE:OFMT_DLESS,
      (method)?k+ikount-1:k+kmax-1, /*C1, now [1] el. contains last interior*/
      skal.lngt*xp[k],skal.lngt*xp[1],xp[k]/xp[1], /* C2, C3, C4 */
      tmp14, /* C5 */
#if NVAR <= 2
      PAD,PAD,PAD,
      PAD,
#else /* NVAR >= 3 */
      skal.lngt*yp[1][k],skal.lngt*yp[3][1],yp[1][k]/yp[3][1], /* C6,C7,C8 */
      tmp15, /* C9 */
#endif
      0.0,0.0,0.0, /* C10, C11, C12 */
      0.0,0.0, /* C13, C14 */
#if ENERGYUNIT <= 1
      skal.mass*yp[2][1],skal.mass*yp[2][1], /* C15, C16 */
#else /* ENERGYUNIT == 2 */
      skal.ergy*yp[2][1],skal.ergy*yp[2][1], /* C15, C16 */
#endif
      skal.lngt*tmp1,skal.lngt*2.*sigma*(polyx+1.)*yp[2][1], /* C17, C18 */
      (xp[k]==0.0)?0.0:tmp1/(2.*xp[k]), /* C19 */
      sigma*(polyx+1.)*yp[2][1]/xp[1], /* C20 */
#if NVAR <= 2
      PAD,
      PAD,
#else /* NVAR >= 3 */
      (yp[1][k]==0.0)?0.0:tmp1/(2.*yp[1][k]), /* C21 */
      sigma*(polyx+1.)*yp[2][1]/yp[3][1], /* C22 */
#endif
      (yp[2][1]==0.0)?1.0:(xp[k]*xp[k]*xp[k]/(3.*yp[2][1])), /* C23 */
      xp[1]*xp[1]*xp[1]/(3.*yp[2][1]), /* C24 */
      tmp10,tmp13, /* C25, C26 */
      1.0/tmp10,1.0/tmp13, /* C27, C28 */
      0.0,0.0, /* C29, C30 */
      0.0,tmp11-1.0,tmp16-1.0, /* C31, C32, C33 */
      0.0,tmp11-1.0, /* C34, C35 */
      tmp16-1.0, /* C36 */
      0.0,0.0, /* C37,C38 */
      1.0-(1.0/tmp11),1.0-(1.0/tmp16), /* C39, C40 */
      1.0-(1.0/tmp11),1.0-(1.0/tmp16),0.0, /* C41, C42, C43 */
#if NVAR <= 3
      PAD,PAD,PAD,
      PAD,
      PAD,
      PAD,
#else /* NVAR >= 4 */
#if ENERGYUNIT == 1
      skal.mass*yp[4][1],skal.mass*yp[4][1],skal.mass*(yp[4][1]-yp[2][1]), /* C44,C45,C46 */
      skal.mass*(yp[4][1]-yp[2][1]), /* C47 */
#else /* ENERGYUNIT == 0 or 2 */
      skal.ergy*yp[4][1],skal.ergy*yp[4][1],skal.ergy*(yp[4][1]-yp[2][1]), /* C44,C45,C46 */
      skal.ergy*(yp[4][1]-yp[2][1]), /* C47 */
#endif
      (yp[4][1]-yp[2][1])/yp[2][1], /* C48 */
      (yp[4][1]-yp[2][1])/yp[2][1], /* C49 */
#endif
#if NVAR <= 4
      PAD,PAD,
      PAD,PAD,
      PAD,
      PAD,
      PAD,
      PAD,
      PAD,PAD,
      PAD,
      PAD,
      PAD,
      PAD,
      PAD,
      PAD,
#else /* NVAR >= 5 */
#if ENERGYUNIT == 1
      skal.mass*yp[5][1],skal.mass*yp[5][1], /* C50, C51 */
      skal.mass*(yp[5][1]-yp[2][1]),skal.mass*(yp[5][1]-yp[2][1]), /*C52,C53*/
#else /* ENERGYUNIT == 0 or 2 */
      skal.ergy*yp[5][1],skal.ergy*yp[5][1], /* C50, C51 */
      skal.ergy*(yp[5][1]-yp[2][1]),skal.ergy*(yp[5][1]-yp[2][1]), /*C52,C53*/
#endif
      (yp[5][1]-yp[2][1])/yp[2][1], /* C54 */
      (yp[5][1]-yp[2][1])/yp[2][1], /* C55 */
      (yp[4][1]-yp[2][1])/yp[5][1], /* C56 */
      (yp[4][1]-yp[2][1])/yp[5][1], /* C57 */
#if ENERGYUNIT == 1
      skal.mass*(yp[4][1]-yp[5][1]),skal.mass*(yp[4][1]-yp[5][1]), /*C58,C59*/
#else /* ENERGYUNIT == 0 or 2 */
      skal.ergy*(yp[4][1]-yp[5][1]),skal.ergy*(yp[4][1]-yp[5][1]), /*C58,C59*/
#endif
      (yp[4][1]-yp[5][1])/yp[2][1], /* C60 */
      (yp[4][1]-yp[5][1])/yp[2][1], /* C61 */
      (yp[5][1]-yp[2][1])/yp[5][1], /* C62 */
      (yp[5][1]-yp[2][1])/yp[5][1], /* C63 */
      (yp[4][1]-yp[5][1])/yp[5][1], /* C64 */
      (yp[4][1]-yp[5][1])/yp[5][1], /* C65 */
#endif
#if NVAR <= 5
      PAD,PAD,PAD,
#else /* NVAR >= 6 */
      yp[2][k],yp[6][1],yp[2][k]/yp[6][1], /* C66, C67, C68 */
#endif
      xp[k]*tmp11,/* C69;defined if NVAR>=2 but sense only if NVAR>=7*/
#if NVAR <= 6
      PAD,PAD,
      PAD,
      PAD,
#else /* NVAR >= 7 */
      yp[3][k],tmp16*yp[7][1], /* C70, C71 */
      (yp[7][1]!=0.)?yp[3][k]/(tmp16*yp[7][1]):0.0, /* C72 */
      tmp13*(1.0-tmp18*tmp18*tmp10), /* C73: optical embeddability function */
#endif
      polyx,sigma,lambda, /* C74, C75, C76 */
      skal.lngt,skal.mass,skal.ergy,skal.dnty,skal.edny,skal.prse /*C77--C82*/
      );
	}
    }
}

void check_magic(void)
/* Checks the magic number in stdin against that contained in method. */
{
    char magic_str[MAGMAX], /* "magic string" placeholder...  */
	*p_mgs;             /* ... and the pointer to it */

    if (!iact) { /* in batch regime only */
	while ((p_mgs=fgets(magic_str,MAGMAX-2,stdin))!=NULL) {/*unless @ EOF*/
	    if ((p_mgs=strstr(p_mgs,MNC""MAGCHR))!=NULL) /* if mag. found...*/
		break;  /* ... leave the while loop */
	}
	if (p_mgs==NULL)
	    cry_err_s("not found in stdin, exiting to system","magic string",
		      1);
	if ((!atoi(p_mgs+2) && method) || (atoi(p_mgs+2) && !method)) {
	    /* p_mgs -> #Mx, p_mgs+2 -> x */
	    cry_err_s("mismatch between option/stdin, exiting to system",\
		      "input dataset",1);
	}
    }
}

void sweep(void)
/* Sweeps temporary file(s). */
{
    (void)fprintf(STDMSG,"All done.  Goodbye.\n");
}


/*
 * $Log: grp_io.c,v $
 * Revision 3.8  2009/10/20 09:34:22  lvs
 * __USE_POSIX2 if-else directive improved
 *
 * Revision 3.7  2009/10/19 23:19:36  lvs
 * ccopt in action again
 *
 * Revision 3.6  2009/10/19 23:07:39  lvs
 * stdio.h wrapped by __USE_POSIX2 to declare popen()/pclose()
 * function prototypes
 * ccopt variable commented out
 *
 * Revision 3.5  2005/10/10 13:10:10  sta
 * bug in grp_io.c fixed
 *
 * Revision 3.4  2005/10/10 12:05:29  sta
 * ENERGYUNIT now 0, 1, 2 for backward compatibility
 *
 * Revision 3.3  2005/10/10 11:22:25  sta
 * ENERGYUNIT introduced
 *
 * Revision 3.2  2005/10/07 18:11:44  sta
 * Bug in K <-> rhoc transformation fixed
 *
 * Revision 3.1  2005/10/07 17:58:41  sta
 * bug in K <-> rhoc transformation fixed
 *
 * Revision 3.0  2005/10/07 17:34:57  sta
 * Starting revision
 *
 * Revision 2.2  2003/02/05 19:16:13  sta
 * I/O bug fixed ('+' replaced by '#', could not reread)
 *
 * Revision 2.1  2003/02/05 18:25:51  sta
 * external extension added
 *
 * Revision 2.0  2003/01/30 20:24:26  sta
 * principal, full fledged revision
 *
 * Revision 1.5  2002-02-08 19:53:11+01  rag
 * Maintenance revision.
 *
 * Revision 1.4  2002-02-05 21:21:32+01  rag
 * Maintenance
 *
 * Revision 1.3  2001/10/05 16:06:33  rag
 * hline() added.
 *
 * Revision 1.2  2001/10/05 15:37:48  rag
 * print_separator() changed.
 *
 * Revision 1.1  2001/10/02 10:51:17  rag
 * Initial revision
 *
 */
