/*
 * ========================================================================
 * $Id: grp_eqs.h,v 3.0 2005/10/07 17:34:57 sta Exp $
 * Revision log is at the end of file.
 * ------------------------------------------------------------------------
 * This header file contains C preprocessor directives, macros, variable
 * declarations and function prototypes specific for the corresponding
 * *.c module.  Caution: this header file is not self-contained. It will
 * fail unless the shared header file grp.h is included before this one.
 * ========================================================================
 */

#ifndef _GRP_EQS_
#define _GRP_EQS_

/* referencing declaration */
extern int adbmode;
extern FTY *xp,**yp;
extern BOOL method;

#endif /* _GRP_EQS_ */

/*
 * $Log: grp_eqs.h,v $
 * Revision 3.0  2005/10/07 17:34:57  sta
 * Starting revision
 *
 * Revision 2.0  2003/01/30 20:24:26  sta
 * principal, full fledged revision
 *
 * Revision 1.2  2002-02-05 21:21:32+01  rag
 * Maintenance
 *
 * Revision 1.1  2001/10/02 10:45:18  rag
 * Initial revision
 *
 */
