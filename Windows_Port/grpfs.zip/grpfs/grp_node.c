/*
 * ========================================================================
 * Linux-to-Windows port based on Linux version
 * $Id: grp_node.c,v 3.0 2005/10/07 17:34:57 sta Exp $
 * ------------------------------------------------------------------------
 * This module contains functions that perform the solution itself.
 * Based on (C) Copr. 1986-92 Numerical Recipes Software &0&35.
 * ========================================================================
 */

#include <stdio.h>
#include <stddef.h> /* may be omitted?? */
#include <math.h>
#include "grp.h"
#include "grp_node.h"

int solve_ode(void)
/* Driver for rkdumb(), odeint(). */
{
    int k,kaz=0,   /* k ante zero of theta */
	nbad,nok,  /* number of good/bad steps taken */
	vno;       /* loop variable */
    FTY x0=XINIT,x2=xg,x2stup=0.0,x1=0.0,x1err=0.0,
	v1=0.0,v1err=0.0,xm=0.0,thetam=0.0,vm=0.0,
	*vstart,h1;
#if NVAR >= 3
    FTY xbar1=0.0,
	xbar1err=0.0,
	xbarm=0.0;
#if NVAR >= 4
    FTY epr1=0.0,
	epr1err=0.0,
	eprm=0.0;
#if NVAR >= 5
    FTY eprg1=0.0,
	eprg1err=0.0,
	eprgm=0.0;
#if NVAR >= 6
    FTY zord1=0.0,
	zord1err=0.0,
	zordm=0.0;
#if NVAR >= 7
    FTY zopt1=0.0,
	zopt1err=0.0,
	zoptm=0.0;
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */

    vstart=vector(1,NVAR);
    /* Note: The arrays xp and yp must have indices up to kmax+1 */
    xp=vector(1,kmax+ekmax+2); /* kmax+1 unused if method>0, not so wasteful */
    yp=matrix(1,NVAR,1,kmax+ekmax+2);

    if (!method) {
/****************************************/
/* INTERNAL SOLUTION, ADAPTIVE STEPSIZE */
/****************************************/
	/* Initial conditions for fixed stepsize methods: */
	vstart[1]=THETA_INI;
	vstart[2]=V_INI;
#if NVAR >= 3
	vstart[3]=XBAR_INI;
#if NVAR >= 4
	vstart[4]=E0_INI;
#if NVAR >= 5
	vstart[5]=E0G_INI;
#if NVAR >= 6
	vstart[6]=ORDEM_INI;
#if NVAR >= 7
	vstart[7]=OPTEM_INI;
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
    }

    if (method) { /* <adaptive stepsize> */
	/* here starts the do-while loop that cycles until the xi guess is */
	/* applicable, i.e., a single nonpositive value of 'theta' remains */
	do {
#ifdef VERBOSE
	    (void)printf(HC"Solving %d coupled interior ODEs...", NVAR);
#endif

	    /* reinitialize because odeint() changes vstart!! */
	    /* I spent 25 mins wondering why odeint() quits unexpectedly. */
	    vstart[1]=THETA_INI;
	    vstart[2]=V_INI;
#if NVAR >= 3
	    vstart[3]=XBAR_INI;
#if NVAR >= 4
	    vstart[4]=E0_INI;
#if NVAR >= 5
	    vstart[5]=E0G_INI;
#if NVAR >= 6
	    vstart[6]=ORDEM_INI;
#if NVAR >= 7
	    vstart[7]=OPTEM_INI;
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */

	    nrhs=0; /* top-level variable also needs reinitializing */

	    /* now (re)initialize quantities required by adaptive methods */
	    dxsav = (kmax>1) ? x2/(kmax-1) : 0.0;
	    h1 = (kmax>1) ? H1SAF*dxsav : H1X2SAF*x2;
	    mxsav = (kmax>1) ? SAVBW*dxsav : x2;

	    switch (method) {
		case 1:  /* adaptive stepsize 5th-ord. Cash-Karp Runge-Kutta */
		    odeint(vstart,NVAR,x0,x2,epsilon,h1,MINALST,&nok,&nbad,rhs_i,rkqs);
		    break;
		case 2: /* adaptive stepsize Bulirsch-Stoer modified midpoint */
		    odeint(vstart,NVAR,x0,x2,epsilon,h1,MINALST,&nok,&nbad,rhs_i,bsstep);
		    break;
		default:
		    cry_err_d("unknown method, using 5th-ord. C-K R-K",
			      method,0);
		    odeint(vstart,NVAR,x0,x2,epsilon,h1,MINALST,&nok,&nbad,rhs_i,rkqs);
		    break;
	    }
#ifdef VERBOSE
	    (void)printf("done.\n");
	    (void)printf(HC"Min sav. < Trial 1st step < Max sav.: %f < %f < %f\n",
			 dxsav,h1,mxsav);
	    (void)printf(HC"Steps acc+rej=tot; Rhs-eval; Pts stored: %d+%d=%d; %d; %d/%d=%.1f%%\n",
			 nok,nbad,nok+nbad,nrhs,kount,kmax,100.0*kount/kmax);
#endif

	    if (kmax == 1) { /* no treating of xi1, no external solution */
		/* finally, we can happily spit out the final values */
		if (isx) (void)printf(HC"No external solution for (max points to save) == 1\n");
		spit_out(1,kount,0);
		free_matrix(yp,1,NVAR,1,kmax+ekmax+2);
		free_vector(xp,1,kmax+ekmax+2);
		free_vector(vstart,1,NVAR);
		return (0);
	    }

	    for (k=1; k<=kount; k++) {
		if (yp[1][k]<=0.0) {
		    kaz=k-1; /* save index of the last positive theta */
		    break;
		}
		if (yp[1][k]>((k>1)?yp[1][k-1]:THETA_INI)) {
		    /* save (-index) just before theta begins to raise */
		    kaz = 1-k;
		    break;
		}
	    }

	    if (kaz==0) { /* all yp[1][k]>0.0, kaz inivalue 0 unchanged */
#ifdef VERBOSE
		(void)printf(HC"Undershot final xi guess %f.\n",x2);
#endif
		x2stup=GCOF*x2/(1-yp[1][kount]);  /* stupid but sure */
		/* interpolate through last four points, x1err is dummy here */
		polint(yp[1]+kount-4, xp+kount-4, IPOLPTS, 0.0, &x2, &x1err);
		x2=FMIN(fabs(x2),x2stup);
#ifdef VERBOSE
		(void)printf(HC"Increasing up to %f.\n",x2);
#endif
	    }
	    else if (kaz<0) { /* theta is not decreasing or constant!! */
#ifdef VERBOSE
		(void)printf(HC"Oops! Increase of theta occurred in (%.5f,%.5f)!\n",
			     xp[-kaz],xp[1-kaz]);
#endif
	    }
	    else if (kaz==1) { /* yp[1][2]<=0.0 (because yp[1][1]==1.0) */
		nrerror("Oops!! Final xi guess too large or #steps too small.");
	    }
	    else if (kaz==kount-1) { /* single occurence yp[1][kount]<=0 */
#ifdef VERBOSE
		(void)printf(HC"Applicable final xi guess.\n");
#endif
	    }
	    else {
#ifdef VERBOSE
		(void)printf(HC"Overshot final xi guess %f.\n",x2);
#endif
		x2=xp[kaz+1];
#ifdef VERBOSE
		(void)printf(HC"Decreasing down to %f.\n",x2);
#endif
	    }
	} while ((kaz != (kount-1)) && (kaz >= 0));
	/* here ends the do-while loop that cycles until the xi guess is */
	/* applicable, i.e., a single nonpositive value of 'theta' remains, */
	/* now we've got applicable final xi guess */

	if (kaz >= 0) {
	    /* from here on, yp[1][kount] <= 0.0 */
	    /* now we have to interpolate, first treating the very probable */
	    /* case that the last 'theta' value is negative */
	    if (yp[1][kount]<0.0) {
#ifdef VERBOSE
		(void)printf(HC"Interpolating through last four points...");
#endif
/* The last four points have indices kount-3, kount-2, kount-1, kount. */
/* NOTE: polints formal args are unit-offset, using `-4' instead of `-3'!! */
/* Having had forgotten about this I spent 20mins wandering why it fails. */
/* (I wrote this part of the code w/o the NRC book.) */
		polint(yp[1]+kount-4, xp+kount-4, IPOLPTS, 0.0, &x1, &x1err);
		polint(xp+kount-4, yp[2]+kount-4, IPOLPTS, x1,  &v1, &v1err);
#if NVAR >= 3
		polint(xp+kount-4,yp[3]+kount-4,IPOLPTS,x1,&xbar1,&xbar1err);
#if NVAR >= 4
		polint(xp+kount-4,yp[4]+kount-4,IPOLPTS,x1,&epr1,&epr1err);
#if NVAR >= 5
		polint(xp+kount-4,yp[5]+kount-4,IPOLPTS,x1,&eprg1,&eprg1err);
#if NVAR >= 6
		polint(xp+kount-4,yp[6]+kount-4,IPOLPTS,x1,&zord1,&zord1err);
#if NVAR >= 7
		polint(xp+kount-4,yp[7]+kount-4,IPOLPTS,x1,&zopt1,&zopt1err);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
/* save `unphysicals' (theta<0) to xm,thetam,vm,xbarm,eprm,eprgm,zordm,zoptm */
		xm=xp[kount];
		thetam=yp[1][kount];
		vm=yp[2][kount];
#if NVAR >= 3
		xbarm=yp[3][kount];
#if NVAR >= 4
		eprm=yp[4][kount];
#if NVAR >= 5
		eprgm=yp[5][kount];
#if NVAR >= 6
		zordm=yp[6][kount];
#if NVAR >= 7
		zoptm=yp[7][kount];
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
/* rewrite (kount)th elem. with x1,0.0,v1,xbar1,epr1,eprg1,zord1,zopt1 */
		xp[kount]=x1;
		yp[1][kount]=0.0;
		yp[2][kount]=v1;
#if NVAR >= 3
		yp[3][kount]=xbar1;
#if NVAR >= 4
		yp[4][kount]=epr1;
#if NVAR >= 5
		yp[5][kount]=eprg1;
#if NVAR >= 6
		yp[6][kount]=zord1;
#if NVAR >= 7
		yp[7][kount]=zopt1;
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */

#ifdef VERBOSE
		(void)printf("done:\n\
"HC""IDT1"xi1    = %+f (Dxi1   = %+.8f, Dxi1/xi1     = %+.1f ppm)\n\
"HC""IDT1"theta1 =  0.0\n\
"HC""IDT1"v1     = %+f (Dv1    = %+.8f, Dv1/v1       = %+.1f ppm)\n",\
			     x1,x1err,1000000.0*x1err/x1,\
			     v1,v1err,1000000.0*v1err/v1);
#if NVAR >= 3
		(void)printf(HC""IDT1"xipr1  = %+f (Dxipr1 = %+.8f, Dxipr1/xipr1 = %+.1f ppm)\n",
			     xbar1,xbar1err,1000000.0*xbar1err/xbar1);
#if NVAR >= 4
		(void)printf(HC""IDT1"epr1   = %+f (Depr1  = %+.8f, Depr1/epr1   = %+.1f ppm)\n",
			     epr1,epr1err,1000000.0*epr1err/epr1);
#if NVAR >= 5
		(void)printf(HC""IDT1"eprg1  = %+f (Deprg1 = %+.8f, Deprg1/eprg1 = %+.1f ppm)\n",
			     eprg1,eprg1err,1000000.0*eprg1err/eprg1);
#if NVAR >= 6
		(void)printf(HC""IDT1"zord1  = %+f (Dzord1 = %+.8f, Dzord1/zord1 = %+.1f ppm)\n",
			     zord1,zord1err,1000000.0*zord1err/zord1);
#if NVAR >= 7
		(void)printf(HC""IDT1"zopt1  = %+f (Dzopt1 = %+.8f, Dzopt1/zopt1 = %+.1f ppm)\n"HC""IDT1"(zopt1 not rescaled yet)\n",
			     zopt1,zopt1err,(zopt1!=0.0)?1000000.0*zopt1err/zopt1:0.0);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
	
#endif /* VERBOSE */
	    }
	    else { /* this is unprobable case, but we include it for sure */
		/* in such case, no interpolation is required */
#ifdef VERBOSE
		(void)printf(HC"Wow, great hit!! The last theta is exact zero!!\n");
#endif
		x1=xp[kount];
		v1=yp[2][kount];
#if NVAR >= 3
		xbar1=yp[3][kount];
#if NVAR >= 4
		epr1=yp[4][kount];
#if NVAR >= 5
		eprg1=yp[5][kount];
#if NVAR >= 6
		zord1=yp[6][kount];
#if NVAR >= 7
		zopt1=yp[7][kount];
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */

#ifdef VERBOSE
		(void)printf(HC""IDT1"xi1    = %+f\n"HC""IDT1"v1     = %+f\n\
"HC""IDT1"theta1 =  0.0\n",
			     x1,v1);
#if NVAR >= 3
		(void)printf(HC""IDT1"xipr1  = %+f\n",xbar1);
#if NVAR >= 4
		(void)printf(HC""IDT1"epr1   = %+f\n",epr1);
#if NVAR >= 5
		(void)printf(HC""IDT1"eprg1  = %+f\n",eprg1);
#if NVAR >= 6
		(void)printf(HC""IDT1"zord1  = %+f\n",zord1);
#if NVAR >= 7
		(void)printf(HC""IDT1"zopt1  = %+f\n"HC""IDT1"(zopt1 not rescaled yet)\n",zopt1);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
#endif /* VERBOSE */
	    }
	    /* ok, we're done with interpolating */

#ifdef VERBOSE
	    (void)printf(HC"Original (unphysical) value of the %d%s point:\n",
			 kount,(kount>3)?"th":((kount<3)?((kount<2)?"st":"nd"):"rd"));
#ifdef DBL_PREC
	    (void)printf(HC""IDT1"xi    = %+.12f\n"HC""IDT1"theta = %+.12f\n"HC""IDT1"v     = %+.12f\n",xm,thetam,vm);
#if NVAR >= 3
	    (void)printf(HC""IDT1"xipr  = %+.12f\n",xbarm);
#if NVAR >= 4
	    (void)printf(HC""IDT1"epr   = %+.12f\n",eprm);
#if NVAR >= 5
	    (void)printf(HC""IDT1"eprg  = %+.12f\n",eprgm);
#if NVAR >= 6
	    (void)printf(HC""IDT1"zord  = %+.12f\n",zordm);
#if NVAR >= 7
	    (void)printf(HC""IDT1"zopt  = %+.12f\n"HC""IDT1"(zopt not rescaled yet)\n",zoptm);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
#else /* DBL_PREC */
	    (void)printf(HC""IDT1"xi    = %+.8f\n"HC""IDT1"theta = %+.8f\n"HC""IDT1"v     = %+.8f\n",xm,thetam,vm);
#if NVAR >= 3
	    (void)printf(HC""IDT1"xipr  = %+.8f\n",xbarm);
#if NVAR >= 4
	    (void)printf(HC""IDT1"epr   = %+.8f\n",eprm);
#if NVAR >= 5
	    (void)printf(HC""IDT1"eprg  = %+.8f\n",eprgm);
#if NVAR >= 6
	    (void)printf(HC""IDT1"zord  = %+.8f\n",zordm);
#if NVAR >= 7
	    (void)printf(HC""IDT1"zopt  = %+.8f\n"HC""IDT1"(zopt not rescaled yet)\n",zoptm);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
#endif /* DBL_PREC */
#endif /* VERBOSE */
	}
	else { /* kaz < 0, i.e., theta has increasing portion!! */
/*          TO BE FINISHED !!!! TO BE INVESTIGATED!!!! */
	    free_matrix(yp,1,NVAR,1,kmax+ekmax+2);
	    free_vector(xp,1,kmax+ekmax+2);
	    free_vector(vstart,1,NVAR);
	    cry_err_s("increase occurred", "theta aka yp[1][]", 2);
	}

/****************************************/
/* EXTERNAL SOLUTION, ADAPTIVE STEPSIZE */
/****************************************/

	ikount=kount; /* save kount, will be rewritten */

	if (isx) {
	    /* pour internal solution into "higher floors" from behind */
	    for (k=ikount;k>=1;k--)
		xp[k+ekmax+1] = xp[k];
	    for (vno=1;vno<=NVAR;vno++)
		for (k=ikount;k>=1;k--)
		    yp[vno][k+ekmax+1] = yp[vno][k];

	    /* reinitialize for external solution */
#if ENVAR >= 1
	    vstart[1]=yp[3][ikount+ekmax+1]; /* 1st eq. is for former 3rd eq.*/
#if ENVAR >= 2
	    vstart[2]=yp[6][ikount+ekmax+1]; /* 2nd eq. is for former 6th eq.*/
#if ENVAR >= 3
	    /* 3rd eq. is for former 7th eq. */
#ifdef DBL_PREC
	    vstart[3]=ZASQRT(G_RR(xp[ikount+ekmax+1],xp[ikount+ekmax+1]*xp[ikount+ekmax+1],yp[2][ikount+ekmax+1],polyx,sigma,lambda))*yp[7][ikount+ekmax+1];
#else /* DBL_PREC */
	    vstart[3]=(float)ZASQRT((double)G_RR(xp[ikount+ekmax+1],xp[ikount+ekmax+1]*xp[ikount+ekmax+1],yp[2][ikount+ekmax+1],polyx,sigma,lambda))*yp[7][ikount+ekmax+1];
#endif /* DBL_PREC */
#endif /* NVAR >= 3 */
#endif /* NVAR >= 2 */
#ifdef VERBOSE
#if ENVAR >= 2
	    (void)printf(HC"Solving %d exterior ODEs...", ENVAR);
#else /* ENVAR >= 2 */
	    (void)printf(HC"Solving %d exterior ODE...", ENVAR);
#endif
#endif
	    nrhs=0; /* top-level variable also needs reinitializing */

	    /* now (re)initialize quantities required by adaptive methods */
	    dxsav = (xfac-1.0)*x1/(ekmax-1);
	    h1 = H1SAF*dxsav;
	    mxsav = SAVBW*dxsav;

	    switch (method) {
		case 1:  /* adaptive stepsize 5th-ord. Cash-Karp Runge-Kutta */
		    odeint(vstart,ENVAR,x1,xfac*x1,epsilon,h1,MINALST,&nok,&nbad,rhs_e,rkqs);
		    break;
		case 2: /* adaptive stepsize Bulirsch-Stoer modified midpoint */
		    odeint(vstart,ENVAR,x1,xfac*x1,epsilon,h1,MINALST,&nok,&nbad,rhs_e,bsstep);
		    break;
		default:
		    cry_err_d("unknown method, using 5th-ord. C-K R-K",
			      method,0);
		    odeint(vstart,ENVAR,x1,xfac*x1,epsilon,h1,MINALST,&nok,&nbad,rhs_e,rkqs);
		    break;
	    }
#ifdef VERBOSE
	    (void)printf("done.\n");
	    (void)printf(HC"Min sav. < Trial 1st step < Max sav.: %f < %f < %f\n",
			 dxsav,h1,mxsav);
	    (void)printf(HC"Steps acc+rej=tot; Rhs-eval; Pts stored: %d+%d=%d; %d; %d/%d=%.1f%%\n",
			 nok,nbad,nok+nbad,nrhs,kount,ekmax,100.0*kount/ekmax);
	    (void)printf(HC"Total points stored: %d/%d=%.1f%%\n",
			 ikount+kount,kmax+ekmax,100.0*(ikount+kount)/(kmax+ekmax));
	    (void)printf(HC"Total pts on output (last int, 1st ext common): %d/%d=%.1f%%\n",
			 ikount+kount-1,kmax+ekmax-1,100.0*(ikount+kount-1)/(kmax+ekmax-1));
#endif
#endif /* NVAR >= 1 */
	    /* index [1] is redundant with [kmax+ekmax+2], so rewrite */
	    /* it back with the [kmax+ekmax+2] element because we */
	    /* don't need the [1] values for external solution (they */
	    /* are given by [kmax+ekmax+2]-th elements */
	    xp[1] = xp[ikount+ekmax+1];
	    for (vno=1;vno<=NVAR;vno++)
		yp[vno][1] = yp[vno][ikount+ekmax+1];
	}
	else
#ifdef VERBOSE
	    (void)printf(HC"No exterior ODEs.\n");
#endif

	/* finally, we can happily spit out the results */
	spit_out(ekmax+2,ikount+ekmax+1,0); /* internal */
	if (isx) spit_out(2,kount,1); /* external,[1]ext=[kmax+ekmax+2]int */

    }

/* </adaptive stepsize> */
    else {

/* <fixed stepsize> */
/*************************************/
/* INTERNAL SOLUTION, FIXED STEPSIZE */
/*************************************/
	/* here starts the do-while loop that cycles until the xi guess is */
	/* applicable, i.e., a single nonpositive value of 'theta' remains */
	do {
#ifdef VERBOSE
	    (void)printf(HC"Solving %d coupled interior ODEs...", NVAR);
#endif
	    /* fixed stepsize 4th-ord. Runge-Kutta */
	    rkdumb(vstart,NVAR,x0,x2,kmax,rhs_i);
#ifdef VERBOSE
	    (void)printf("done.\n");
#endif
	    for (k=1; k<=kmax+1; k++) {
		if (yp[1][k]<=0.0) {
		    kaz=k-1; /* save index of the last positive theta */
		    break;
		}
		if (yp[1][k]>((k>1)?yp[1][k-1]:THETA_INI)) {
		    kaz = 1-k; /* save (-index) just before theta increases */
		    break;
		}
	    }
	    if (kaz==0) { /* all yp[1][k]>0.0, kaz inivalue 0 unchanged */
#ifdef VERBOSE
		(void)printf(HC"Undershot final xi guess %f.\n",x2);
#endif
		x2stup=GCOF*x2/(1-yp[1][kmax+1]);  /* stupid but sure */
		/* interpolate through last four points, x1err is dummy here */
		polint(yp[1]+kmax-3, xp+kmax-3, IPOLPTS, 0.0, &x2, &x1err);
		x2=FMIN(fabs(x2),x2stup);
#ifdef VERBOSE
		(void)printf(HC"Increasing up to %f.\n",x2);
#endif
	    }
	    else if (kaz<0) { /* theta is not decreasing or constant!! */
#ifdef VERBOSE
		(void)printf(HC"Oops! Increase of theta occurred in (%.5f,%.5f)!\n",\
			     xp[-kaz],xp[1-kaz]);
#endif
	    }
	    else if (kaz==1) { /* yp[1][2]<=0.0 (because yp[1][1]==1.0) */
		nrerror("Oops!! Final xi guess too large or #steps too small.");
	    }
	    else if (kaz==kmax) { /* single occurence yp[1][kmax+1]<=0 */
#ifdef VERBOSE
		(void)printf(HC"Applicable final xi guess.\n");
#endif
	    }
	    else {
#ifdef VERBOSE
		(void)printf(HC"Overshot final xi guess %f.\n",x2);
#endif
		x2=xp[kaz+1];
#ifdef VERBOSE
		(void)printf(HC"Decreasing down to %f.\n",x2);
#endif
	    }
	} while ((kaz != kmax) && (kaz >= 0));
	/* here ends the do-while loop that cycles until the xi guess is */
	/* applicable, i.e., a single nonpositive value of 'theta' remains, */
	/* now we've got applicable final xi guess */

	if (kaz >= 0) {
	    /* from here on, yp[1][kmax+1] <= 0.0 */
	    /* now we have to interpolate, first treating the very probable */
	    /* case that the last 'theta' value is negative */
	    if (yp[1][kmax+1]<0.0) {
#ifdef VERBOSE
		(void)printf(HC"Interpolating through last four points...");
#endif
/* The last four points have indices kmax-2, kmax-1, kmax, kmax+1. */
/* NOTE: polints formal args are unit-offset, using `-3' instead of `-2'!! */
/* Having had forgotten about this I spent 20mins wandering why it fails. */
/* (I wrote this part of the code w/o the NRC book.) */
		polint(yp[1]+kmax-3, xp+kmax-3, IPOLPTS, 0.0, &x1, &x1err);
		polint(xp+kmax-3, yp[2]+kmax-3, IPOLPTS, x1,  &v1, &v1err);
#if NVAR >= 3
		polint(xp+kmax-3,yp[3]+kmax-3,IPOLPTS,x1,&xbar1,&xbar1err);
#if NVAR >= 4
		polint(xp+kmax-3,yp[4]+kmax-3,IPOLPTS,x1,&epr1,&epr1err);
#if NVAR >= 5
		polint(xp+kmax-3,yp[5]+kmax-3,IPOLPTS,x1,&eprg1,&eprg1err);
#if NVAR >= 6
		polint(xp+kmax-3,yp[6]+kmax-3,IPOLPTS,x1,&zord1,&zord1err);
#if NVAR >= 7
		polint(xp+kmax-3,yp[7]+kmax-3,IPOLPTS,x1,&zopt1,&zopt1err);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
/* save `unphysicals' (theta<0) to xm,thetam,vm,xbarm,eprm,eprgm,zordm,zoptm */
		xm=xp[kmax+1];
		thetam=yp[1][kmax+1];
		vm=yp[2][kmax+1];
#if NVAR >= 3
		xbarm=yp[3][kmax+1];
#if NVAR >= 4
		eprm=yp[4][kmax+1];
#if NVAR >= 5
		eprgm=yp[5][kmax+1];
#if NVAR >= 6
		zordm=yp[6][kmax+1];
#if NVAR >= 7
		zoptm=yp[7][kmax+1];
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
/* rewrite (kmax+1)th elem. with x1,0.0,v1,xbar1,epr1,eprg1,zord1,zopt1 */
		xp[kmax+1]=x1;
		yp[1][kmax+1]=0.0;
		yp[2][kmax+1]=v1;
#if NVAR >= 3
		yp[3][kmax+1]=xbar1;
#if NVAR >= 4
		yp[4][kmax+1]=epr1;
#if NVAR >= 5
		yp[5][kmax+1]=eprg1;
#if NVAR >= 6
		yp[6][kmax+1]=zord1;
#if NVAR >= 7
		yp[7][kmax+1]=zopt1;
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */

#ifdef VERBOSE
		(void)printf("done:\n\
"HC""IDT1"xi1    = %+f (Dxi1   = %+.8f, Dxi1/xi1     = %+.1f ppm)\n\
"HC""IDT1"theta1 =  0.0\n\
"HC""IDT1"v1     = %+f (Dv1    = %+.8f, Dv1/v1       = %+.1f ppm)\n",\
			     x1,x1err,1000000.0*x1err/x1,\
			     v1,v1err,1000000.0*v1err/v1);
#if NVAR >= 3
		(void)printf(HC""IDT1"xipr1  = %+f (Dxipr1 = %+.8f, Dxipr1/xipr1 = %+.1f ppm)\n",
			     xbar1,xbar1err,1000000.0*xbar1err/xbar1);
#if NVAR >= 4
		(void)printf(HC""IDT1"epr1   = %+f (Depr1  = %+.8f, Depr1/epr1   = %+.1f ppm)\n",
			     epr1,epr1err,1000000.0*epr1err/epr1);
#if NVAR >= 5
		(void)printf(HC""IDT1"eprg1  = %+f (Deprg1 = %+.8f, Deprg1/eprg1 = %+.1f ppm)\n",
			     eprg1,eprg1err,1000000.0*eprg1err/eprg1);
#if NVAR >= 6
		(void)printf(HC""IDT1"zord1  = %+f (Dzord1 = %+.8f, Dzord1/zord1 = %+.1f ppm)\n",
			     zord1,zord1err,1000000.0*zord1err/zord1);
#if NVAR >= 7
		(void)printf(HC""IDT1"zopt1  = %+f (Dzopt1 = %+.8f, Dzopt1/zopt1 = %+.1f ppm)\n"HC""IDT1"(zopt1 not rescaled yet)\n",
			     zopt1,zopt1err,(zopt1!=0.0)?1000000.0*zopt1err/zopt1:0.0);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
	
#endif /* VERBOSE */
	    }
	    else { /* this is unprobable case, but we include it for sure */
		/* in such case, no interpolation is required */
#ifdef VERBOSE
		(void)printf(HC"Wow, great hit!! The last theta is exact zero!!\n");
#endif
		x1=xp[kmax+1];
		v1=yp[2][kmax+1];
#if NVAR >= 3
		xbar1=yp[3][kmax+1];
#if NVAR >= 4
		epr1=yp[4][kmax+1];
#if NVAR >= 5
		eprg1=yp[5][kmax+1];
#if NVAR >= 6
		zord1=yp[6][kmax+1];
#if NVAR >= 7
		zopt1=yp[7][kmax+1];
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */

#ifdef VERBOSE
		(void)printf(HC""IDT1"xi1    = %+f\n"HC""IDT1"v1     = %+f\n\
"HC""IDT1"theta1 =  0.0\n",
			     x1,v1);
#if NVAR >= 3
		(void)printf(HC""IDT1"xipr1  = %+f\n",xbar1);
#if NVAR >= 4
		(void)printf(HC""IDT1"epr1   = %+f\n",epr1);
#if NVAR >= 5
		(void)printf(HC""IDT1"eprg1  = %+f\n",eprg1);
#if NVAR >= 6
		(void)printf(HC""IDT1"zord1  = %+f\n",zord1);
#if NVAR >= 7
		(void)printf(HC""IDT1"zopt1  = %+f\n"HC""IDT1"(zopt1 not rescaled yet)\n",zopt1);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
#endif /* VERBOSE */
	    }
	    /* ok, we're done with interpolating */

#ifdef VERBOSE
	    (void)printf(HC"Original (unphysical) value of the %d%s point:\n",kmax,(kmax>3)?"th":((kmax<3)?((kmax<2)?"st":"nd"):"rd"));
#ifdef DBL_PREC
	    (void)printf(HC""IDT1"xi    = %+.12f\n"HC""IDT1"theta = %+.12f\n"HC""IDT1"v     = %+.12f\n",xm,thetam,vm);
#if NVAR >= 3
	    (void)printf(HC""IDT1"xipr  = %+.12f\n",xbarm);
#if NVAR >= 4
	    (void)printf(HC""IDT1"epr   = %+.12f\n",eprm);
#if NVAR >= 5
	    (void)printf(HC""IDT1"eprg  = %+.12f\n",eprgm);
#if NVAR >= 6
	    (void)printf(HC""IDT1"zord  = %+.12f\n",zordm);
#if NVAR >= 7
	    (void)printf(HC""IDT1"zopt  = %+.12f\n"HC""IDT1"(zopt not rescaled yet)\n",zoptm);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
#else /* DBL_PREC */
	    (void)printf(HC""IDT1"xi    = %+.8f\n"HC""IDT1"theta = %+.8f\n"HC""IDT1"v     = %+.8f\n",xm,thetam,vm);
#if NVAR >= 3
	    (void)printf(HC""IDT1"xipr  = %+.8f\n",xbarm);
#if NVAR >= 4
	    (void)printf(HC""IDT1"epr   = %+.8f\n",eprm);
#if NVAR >= 5
	    (void)printf(HC""IDT1"eprg  = %+.8f\n",eprgm);
#if NVAR >= 6
	    (void)printf(HC""IDT1"zord  = %+.8f\n",zordm);
#if NVAR >= 7
	    (void)printf(HC""IDT1"zopt  = %+.8f\n"HC""IDT1"(zopt not rescaled yet)\n",zoptm);
#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
#endif /* DBL_PREC */
#endif /* VERBOSE */

	}
	else { /* kaz < 0, i.e., theta has increasing portion!! */
/*          TO BE FINISHED !!!! TO BE INVESTIGATED!!!! */
	    /* free the memory */
	    free_matrix(yp,1,NVAR,1,kmax+ekmax+2);
	    free_vector(xp,1,kmax+ekmax+2);
	    free_vector(vstart,1,NVAR);
	    cry_err_s("increase occurred", "theta aka yp[1][]", 2);
	}

/*************************************/
/* EXTERNAL SOLUTION, FIXED STEPSIZE */
/*************************************/

	if (isx) {
	    /* pour internal solution into "higher floors" from behind */
	    for (k=kmax+1;k>=1;k--)
		xp[k+ekmax+1] = xp[k];
	    for (vno=1;vno<=NVAR;vno++)
		for (k=kmax+1;k>=1;k--)
		    yp[vno][k+ekmax+1] = yp[vno][k];

	    /* reinitialize for external solution */
#if ENVAR >= 1
	    vstart[1]=yp[3][kmax+ekmax+2]; /* 1st eq. is for former 3rd eq. */
#if ENVAR >= 2
	    vstart[2]=yp[6][kmax+ekmax+2]; /* 2nd eq. is for former 6th eq. */
#if ENVAR >= 3
	    /* 3rd eq. is for former 7th eq. */
#ifdef DBL_PREC
	    vstart[3]=ZASQRT(G_RR(xp[kmax+ekmax+2],xp[kmax+ekmax+2]*xp[kmax+ekmax+2],yp[2][kmax+ekmax+2],polyx,sigma,lambda))*yp[7][kmax+ekmax+2];
#else /* DBL_PREC */
	    vstart[3]=(float)ZASQRT((double)G_RR(xp[kmax+ekmax+2],xp[kmax+ekmax+2]*xp[kmax+ekmax+2],yp[2][kmax+ekmax+2],polyx,sigma,lambda))*yp[7][kmax+ekmax+2];
#endif /* DBL_PREC */
#endif /* NVAR >= 3 */
#endif /* NVAR >= 2 */
#ifdef VERBOSE
#if ENVAR >= 2
	    (void)printf(HC"Solving %d exterior ODEs...", ENVAR);
#else /* ENVAR >= 2 */
	    (void)printf(HC"Solving %d exterior ODE...", ENVAR);
#endif
#endif
	    /* fixed stepsize 4th-ord. Runge-Kutta */
	    rkdumb(vstart,ENVAR,x1,xfac*x1,ekmax,rhs_e);
#ifdef VERBOSE
	    (void)printf("done.\n");
#endif
#endif /* NVAR >= 1 */
	    /* index [1] is redundant with [kmax+ekmax+2], so rewrite */
	    /* it back with the [kmax+ekmax+2] element because we */
	    /* don't need the [1] values for external solution (they */
	    /* are given by [kmax+ekmax+2]-th elements */
	    xp[1] = xp[kmax+ekmax+2];
	    for (vno=1;vno<=NVAR;vno++)
		yp[vno][1] = yp[vno][kmax+ekmax+2];
	}
	else
#ifdef VERBOSE
	    (void)printf(HC"No exterior ODEs.\n");
#endif

	/* finally, we can happily spit out the results */
	spit_out(ekmax+2,kmax+ekmax+2,0); /* internal */
	if (isx) spit_out(2,ekmax+1,1); /* external,[1]ext=[kmax+ekmax+2]int */

    } /* </fixed stepsize> */

    /* at the end, it's fair to free the memory */
    free_matrix(yp,1,NVAR,1,kmax+ekmax+2);
    free_vector(xp,1,kmax+ekmax+2);
    free_vector(vstart,1,NVAR);

    return (0);
}

void rkdumb(FTY vstart[],int nvar,FTY x0,FTY x2,int nstep,
	    void (*derivs)(const FTY,FTY [],FTY []))
/* Fixed-stepsize driver for rk4(). */
{
    int i,k;
    FTY xk,h;
    FTY *v,*vout,*dv;

    v=vector(1,nvar);
    vout=vector(1,nvar);
    dv=vector(1,nvar);
    for (i=1;i<=nvar;i++) {
	v[i]=vstart[i];
	yp[i][1]=v[i];
    }
    xp[1]=x0;
    xk=x0;
    h=(x2-x0)/nstep;
    for (k=1;k<=nstep;k++) {
	(*derivs)(xk,v,dv);
	rk4(v,dv,nvar,xk,h,vout,derivs);
	if ((FTY)(xk+h) ==xk) nrerror("Step size too small in routine rkdumb");
	xk += h;
	xp[k+1]=xk;
	for (i=1;i<=nvar;i++) {
	    v[i]=vout[i];
	    yp[i][k+1]=v[i];
	}
    }
    free_vector(dv,1,nvar);
    free_vector(vout,1,nvar);
    free_vector(v,1,nvar);
}

void rk4(FTY y[],FTY dydx[],int n,FTY xk,FTY h,FTY yout[],
	 void (*derivs)(const FTY,FTY [],FTY []))
/* Fourth-order Runge--Kutta propagator (alorithm).*/
{
    int i;
    FTY xh,hh,h6,*dym,*dyt,*yt;

    dym=vector(1,n);
    dyt=vector(1,n);
    yt=vector(1,n);
    hh=h*0.5;
    h6=h/6.0;
    xh=xk+hh;
    for (i=1;i<=n;i++) yt[i]=y[i]+hh*dydx[i];
    (*derivs)(xh,yt,dyt);
    for (i=1;i<=n;i++) yt[i]=y[i]+hh*dyt[i];
    (*derivs)(xh,yt,dym);
    for (i=1;i<=n;i++) {
	yt[i]=y[i]+h*dym[i];
	dym[i] += dyt[i];
    }
    (*derivs)(xk+h,yt,dyt);
    for (i=1;i<=n;i++)
	yout[i]=y[i]+h6*(dydx[i]+dyt[i]+2.0*dym[i]);
    free_vector(yt,1,n);
    free_vector(dyt,1,n);
    free_vector(dym,1,n);
}

void odeint(FTY ystart[], int nvar, FTY x0, FTY x2, FTY eps, FTY h1,
	    FTY hmin, int *nok, int *nbad,
	    void (*derivs)(const FTY, FTY [], FTY []),
	    void (*stepper)(FTY [],FTY [],int,FTY *,FTY,FTY,FTY [],
			 FTY *,FTY *,void (*)(FTY,FTY [],FTY [])))
/* Driver with adaptive stepsize control. */
{
    int nstp,i;
    FTY xsav=0.0,xo,hnext,hdid,h;
    FTY *yscal,*y,*dydx;

    yscal=vector(1,nvar);
    y=vector(1,nvar);
    dydx=vector(1,nvar);
    xo=x0;
    h=SIGN(h1,x2-x0);
    *nok = (*nbad) = kount = 0;
    for (i=1;i<=nvar;i++) y[i]=ystart[i];
    if (kmax > 0) xsav=xo-dxsav*2.0;
    for (nstp=1;nstp<=MAXSTP;nstp++) {
	(*derivs)(xo,y,dydx);
	for (i=1;i<=nvar;i++) { /* see global header file for explanation */
#if YSCAL==1
	    yscal[i]=fabs(y[i])+TINY;
#elif YSCAL==2
	    yscal[i]=YMAX;
#elif YSCAL==3
	    yscal[i]=FMAX(YMAX,fabs(y[i]));
#elif YSCAL==4
	    yscal[i]=fabs(dydx[i]*h)+TINY;
#else /* YSCAL==0 */
	    yscal[i]=fabs(y[i])+fabs(dydx[i]*h)+TINY; /* default */
#endif
	}
	/* the following lines can be tailored to match your needs */
	if (kmax > 0 && kount < kmax-1 && fabs(xo-xsav) > fabs(dxsav)) {
	    xp[++kount]=xo;
	    for (i=1;i<=nvar;i++) yp[i][kount]=y[i];
	    xsav=xo;
	}
	if ((xo+h-x2)*(xo+h-x0) > 0.0) h=x2-xo;
	(*stepper)(y,dydx,nvar,&xo,h,eps,yscal,&hdid,&hnext,derivs);
	if (hdid == h) ++(*nok); else ++(*nbad);
	if ((xo-x2)*(x2-x0) >= 0.0) {
	    for (i=1;i<=nvar;i++) ystart[i]=y[i];
	    if (kmax) {
		xp[++kount]=xo;
		for (i=1;i<=nvar;i++) yp[i][kount]=y[i];
	    }
	    free_vector(dydx,1,nvar);
	    free_vector(y,1,nvar);
	    free_vector(yscal,1,nvar);
	    return;
	}
	if (fabs(hnext) <= hmin) nrerror("Step size too small in odeint");
	h=hnext;
    }
    nrerror("Too many steps in routine odeint");
}

void rkqs(FTY y[], FTY dydx[], int n, FTY *xq, FTY htry, FTY eps,
	  FTY yscal[], FTY *hdid, FTY *hnext,
	  void (*derivs)(const FTY, FTY [], FTY []))
/* Fifth-order Runge--Kutta step with monitoring of local truncation error */
/* to ensure accuracy and adjust stepsize. */
{
    int i;
    FTY errmax,h,htemp,xnew,*yerr,*ytemp;

    yerr=vector(1,n);
    ytemp=vector(1,n);
    h=htry;
    for (;;) {
	rkck(y,dydx,n,*xq,h,ytemp,yerr,derivs);
	errmax=0.0;
	for (i=1;i<=n;i++) errmax=FMAX(errmax,fabs(yerr[i]/yscal[i]));
	errmax /= eps;
	if (errmax <= 1.0) break;
	htemp=SAFETY*h*pow(errmax,PSHRNK);
	h=(h >= 0.0 ? FMAX(htemp,0.1*h) : FMIN(htemp,0.1*h));
	xnew=(*xq)+h;
	if (xnew == *xq) nrerror("stepsize underflow in rkqs");
    }
    if (errmax > ERRCON) *hnext=SAFETY*h*pow(errmax,PGROW);
    else *hnext=INCRF*h; /* ---sh: originally 5.0 instead of INCRF */
/* ---sh: inclusion to cut off the stepsize */
#if APPLYMXSAV >= 1
    if (kmax > 3)
	*hnext = (*hnext>=0.0 ? FMIN(mxsav,*hnext) : FMAX(-mxsav,*hnext));
#endif /* APPLYMXSAV */
/* ---sh: end inclusion */
    *xq += (*hdid=h);
    for (i=1;i<=n;i++) y[i]=ytemp[i];
    free_vector(ytemp,1,n);
    free_vector(yerr,1,n);
}

void rkck(FTY y[], FTY dydx[], int n, FTY xkk, FTY h, FTY yout[],
	  FTY yerr[], void (*derivs)(const FTY, FTY [], FTY []))
/* Fifth-order Cash--Karp Runge--Kutta propagator (algorithm). */
{
    int i;
    static FTY a2=0.2,a3=0.3,a4=0.6,a5=1.0,a6=0.875,b21=0.2,
	b31=3.0/40.0,b32=9.0/40.0,b41=0.3,b42 = -0.9,b43=1.2,
	b51 = -11.0/54.0, b52=2.5,b53 = -70.0/27.0,b54=35.0/27.0,
	b61=1631.0/55296.0,b62=175.0/512.0,b63=575.0/13824.0,
	b64=44275.0/110592.0,b65=253.0/4096.0,c1=37.0/378.0,
	c3=250.0/621.0,c4=125.0/594.0,c6=512.0/1771.0,
	dc5 = -277.00/14336.0;
    FTY dc1=c1-2825.0/27648.0,dc3=c3-18575.0/48384.0,
	dc4=c4-13525.0/55296.0,dc6=c6-0.25;
    FTY *ak2,*ak3,*ak4,*ak5,*ak6,*ytemp;

    ak2=vector(1,n);
    ak3=vector(1,n);
    ak4=vector(1,n);
    ak5=vector(1,n);
    ak6=vector(1,n);
    ytemp=vector(1,n);
    for (i=1;i<=n;i++)
	ytemp[i]=y[i]+b21*h*dydx[i];
    (*derivs)(xkk+a2*h,ytemp,ak2);
    for (i=1;i<=n;i++)
	ytemp[i]=y[i]+h*(b31*dydx[i]+b32*ak2[i]);
    (*derivs)(xkk+a3*h,ytemp,ak3);
    for (i=1;i<=n;i++)
	ytemp[i]=y[i]+h*(b41*dydx[i]+b42*ak2[i]+b43*ak3[i]);
    (*derivs)(xkk+a4*h,ytemp,ak4);
    for (i=1;i<=n;i++)
	ytemp[i]=y[i]+h*(b51*dydx[i]+b52*ak2[i]+b53*ak3[i]+b54*ak4[i]);
    (*derivs)(xkk+a5*h,ytemp,ak5);
    for (i=1;i<=n;i++)
	ytemp[i]=y[i]+h*(b61*dydx[i]+b62*ak2[i]+b63*ak3[i]+b64*ak4[i]+b65*ak5[i]);
    (*derivs)(xkk+a6*h,ytemp,ak6);
    for (i=1;i<=n;i++)
	yout[i]=y[i]+h*(c1*dydx[i]+c3*ak3[i]+c4*ak4[i]+c6*ak6[i]);
    for (i=1;i<=n;i++)
	yerr[i]=h*(dc1*dydx[i]+dc3*ak3[i]+dc4*ak4[i]+dc5*ak5[i]+dc6*ak6[i]);
    free_vector(ytemp,1,n);
    free_vector(ak6,1,n);
    free_vector(ak5,1,n);
    free_vector(ak4,1,n);
    free_vector(ak3,1,n);
    free_vector(ak2,1,n);
}

void bsstep(FTY y[], FTY dydx[], int nv, FTY *xx, FTY htry, FTY eps,
	    FTY yscal[], FTY *hdid, FTY *hnext,
	    void (*derivs)(const FTY, FTY [], FTY []))
/* Bulirsch--Stoer step with monitoring of local truncation error */
/* to ensure accuracy and adjust stepsize. */
{
    int i,iq,k,kk,km=0;
    static int first=1,bkmax,kopt;
    static FTY epsold = -1.0,xnew;
    FTY eps1,errmax,fact,h,red=0.0,scale=0.0,work,wrkmin,xest;
    FTY *err,*yerr,*ysav,*yseq;
    static FTY a[IMAXX+1];
    static FTY alf[KMAXX+1][KMAXX+1];
    static int nseq[IMAXX+1]={0,2,4,6,8,10,12,14,16,18};
    int reduct,exitflag=0;

    d=matrix(1,nv,1,KMAXX);
    err=vector(1,KMAXX);
    x=vector(1,KMAXX);
    yerr=vector(1,nv);
    ysav=vector(1,nv);
    yseq=vector(1,nv);
    if (eps != epsold) {
	*hnext = xnew = -1.0e29;
	eps1=SAFE1*eps;
	a[1]=nseq[1]+1;
	for (k=1;k<=KMAXX;k++) a[k+1]=a[k]+nseq[k+1];
	for (iq=2;iq<=KMAXX;iq++) {
	    for (k=1;k<iq;k++)
		alf[k][iq]=pow(eps1,(a[k+1]-a[iq+1])/
			       ((a[iq+1]-a[1]+1.0)*(2*k+1)));
	}
	epsold=eps;
	for (kopt=2;kopt<KMAXX;kopt++)
	    if (a[kopt+1] > a[kopt]*alf[kopt-1][kopt]) break;
	bkmax=kopt;
    }
    h=htry;
    for (i=1;i<=nv;i++) ysav[i]=y[i];
    if (*xx != xnew || h != (*hnext)) {
	first=1;
	kopt=bkmax;
    }
    reduct=0;
    for (;;) {
	for (k=1;k<=bkmax;k++) {
	    xnew=(*xx)+h;
	    if (xnew == (*xx)) nrerror("step size underflow in bsstep");
	    mmid(ysav,dydx,nv,*xx,h,nseq[k],yseq,derivs);
	    xest=SQR(h/nseq[k]);
#ifdef RAT_EXTR
	    rzextr(k,xest,yseq,y,yerr,nv);
#else
	    pzextr(k,xest,yseq,y,yerr,nv);
#endif

	    if (k != 1) {
		errmax=BTINY;
		for (i=1;i<=nv;i++) errmax=FMAX(errmax,fabs(yerr[i]/yscal[i]));
		errmax /= eps;
		km=k-1;
		err[km]=pow(errmax/SAFE1,1.0/(2*km+1));
	    }
	    if (k != 1 && (k >= kopt-1 || first)) {
		if (errmax < 1.0) {
		    exitflag=1;
		    break;
		}
		if (k == bkmax || k == kopt+1) {
		    red=SAFE2/err[km];
		    break;
		}
		else if (k == kopt && alf[kopt-1][kopt] < err[km]) {
		    red=1.0/err[km];
		    break;
		}
		else if (kopt == bkmax && alf[km][bkmax-1] < err[km]) {
		    red=alf[km][bkmax-1]*SAFE2/err[km];
		    break;
		}
		else if (alf[km][kopt] < err[km]) {
		    red=alf[km][kopt-1]/err[km];
		    break;
		}
	    }
	}
	if (exitflag) break;
	red=FMIN(red,REDMIN);
	red=FMAX(red,REDMAX);
	h *= red;
	reduct=1;
    }
    *xx=xnew;
    *hdid=h;
    first=0;
    wrkmin=1.0e35;
    for (kk=1;kk<=km;kk++) {
	fact=FMAX(err[kk],SCALMX);
	work=fact*a[kk+1];
	if (work < wrkmin) {
	    scale=fact;
	    wrkmin=work;
	    kopt=kk+1;
	}
    }
    *hnext=h/scale;
    if (kopt >= k && kopt != bkmax && !reduct) {
	fact=FMAX(scale/alf[kopt-1][kopt],SCALMX);
	if (a[kopt+1]*fact <= wrkmin) {
	    *hnext=h/fact;
	    kopt++;
	}
    }
/* ---sh: inclusion to cut off the stepsize */
#if APPLYMXSAV >= 1
    if (bkmax > 3)
	*hnext = (*hnext>=0.0 ? FMIN(mxsav,*hnext) : FMAX(-mxsav,*hnext));
#endif /* APPLYMXSAV */
/* ---sh: end inclusion */
    free_vector(yseq,1,nv);
    free_vector(ysav,1,nv);
    free_vector(yerr,1,nv);
    free_vector(x,1,KMAXX);
    free_vector(err,1,KMAXX);
    free_matrix(d,1,nv,1,KMAXX);
}

void mmid(FTY y[], FTY dydx[], int nvar, FTY xs, FTY htot, int nstep,
	  FTY yout[], void (*derivs)(const FTY, FTY[], FTY[]))
/* Modified midpoint step. */
{
    int n,i;
    FTY xmm,swap,h2,h,*ym,*yn;

    ym=vector(1,nvar);
    yn=vector(1,nvar);
    h=htot/nstep;
    for (i=1;i<=nvar;i++) {
	ym[i]=y[i];
	yn[i]=y[i]+h*dydx[i];
    }
    xmm=xs+h;
    (*derivs)(xmm,yn,yout);
    h2=2.0*h;
    for (n=2;n<=nstep;n++) {
	for (i=1;i<=nvar;i++) {
	    swap=ym[i]+h2*yout[i];
	    ym[i]=yn[i];
	    yn[i]=swap;
	}
	xmm += h;
	(*derivs)(xmm,yn,yout);
    }
    for (i=1;i<=nvar;i++)
	yout[i]=0.5*(ym[i]+yn[i]+h*yout[i]);
    free_vector(yn,1,nvar);
    free_vector(ym,1,nvar);
}

void pzextr(int iest, FTY xest, FTY yest[], FTY yz[], FTY dy[], int nv)
/* Polynomial extrapolation for bsstep(). */
{
    int k1,j;
    FTY q,f2,f1,delta,*c;

    c=vector(1,nv);
    x[iest]=xest;
    for (j=1;j<=nv;j++) dy[j]=yz[j]=yest[j];
    if (iest == 1) {
	for (j=1;j<=nv;j++) d[j][1]=yest[j];
    } else {
	for (j=1;j<=nv;j++) c[j]=yest[j];
	for (k1=1;k1<iest;k1++) {
	    delta=1.0/(x[iest-k1]-xest);
	    f1=xest*delta;
	    f2=x[iest-k1]*delta;
	    for (j=1;j<=nv;j++) {
		q=d[j][k1];
		d[j][k1]=dy[j];
		delta=c[j]-q;
		dy[j]=f1*delta;
		c[j]=f2*delta;
		yz[j] += dy[j];
	    }
	}
	for (j=1;j<=nv;j++) d[j][iest]=dy[j];
    }
    free_vector(c,1,nv);
}

void rzextr(int iest, FTY xest, FTY yest[], FTY yz[], FTY dy[], int nv)
/* Rational extrapolation for bsstep(). */
{
    int k,j;
    FTY yy,v,ddy=0.0,c,b1,b,*fx;

    fx=vector(1,iest);
    x[iest]=xest;
    if (iest == 1)
	for (j=1;j<=nv;j++) {
	    yz[j]=yest[j];
	    d[j][1]=yest[j];
	    dy[j]=yest[j];
	}
    else {
	for (k=1;k<iest;k++)
	    fx[k+1]=x[iest-k]/xest;
	for (j=1;j<=nv;j++) {
	    v=d[j][1];
	    d[j][1]=yy=c=yest[j];
	    for (k=2;k<=iest;k++) {
		b1=fx[k]*v;
		b=b1-c;
		if (b) {
		    b=(c-v)/b;
		    ddy=c*b;
		    c=b1*b;
		} else
		    ddy=v;
		if (k != iest) v=d[j][k];
		d[j][k]=ddy;
		yy += ddy;
	    }
	    dy[j]=ddy;
	    yz[j]=yy;
	}
    }
    free_vector(fx,1,iest);
}

void polint(FTY xa[], FTY ya[], int n, FTY xin, FTY *y, FTY *dy)
/* Polynomial interpolation. */
{
    int i,m,ns=1;
    FTY den,dif,dift,ho,hp,w;
    FTY *pc,*pd;

    dif=fabs(xin-xa[1]);
    pc=vector(1,n);
    pd=vector(1,n);
    for (i=1;i<=n;i++) {
	if ( (dift=fabs(xin-xa[i])) < dif) {
	    ns=i;
	    dif=dift;
	}
	pc[i]=ya[i];
	pd[i]=ya[i];
    }
    *y=ya[ns--];
    for (m=1;m<n;m++) {
	for (i=1;i<=n-m;i++) {
	    ho=xa[i]-xin;
	    hp=xa[i+m]-xin;
	    w=pc[i+1]-pd[i];
	    if ( (den=ho-hp) == 0.0) nrerror("Error in routine polint");
	    den=w/den;
	    pd[i]=hp*den;
	    pc[i]=ho*den;
	}
	*y += (*dy=(2*ns < (n-m) ? pc[ns+1] : pd[ns--]));
    }
    free_vector(pd,1,n);
    free_vector(pc,1,n);
}
