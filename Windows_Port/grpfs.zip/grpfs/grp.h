/*
 * ========================================================================
 * Linux-to-Windows port based on Linux version
 * $Id: grp.h,v 3.3 2005/10/10 13:10:10 sta Exp $
 * ------------------------------------------------------------------------
 * This header file contains C preprocessor directives, macros,
 * variable declarations and function prototypes shared by two
 * or more *.c modules. Including this header file must precede
 * including any other (module-specific) header.
 * ========================================================================
 */

#ifndef _GRP_
#define _GRP_

/* <CUSTOMIZATION SECTION> */
/* whether to print #OUTPUT <number of data rows> just before the */
/* output or not (comment out or uncomment the next directive) */
/* #define PURE_DATA */
/* ====================================================================== */
/* string containing the name of the program (executable may append .x)... */
#define CNAME "grpfs"
#define CNAME_A "grafs"
/* ...and the author's name */
#define CAUTH "S. Hledik"
/* ====================================================================== */
/* Uncomment the C preprocessor directive below you want to bring into */
/* work. But better way of doing so is using the "gcc -D<option> ...", */
/* e.g., "gcc -DDBL_PREC ..." to ensure double precision. See Makefile. */
#define DBL_PREC  /* double precision floating-point arithmetic */
#define VERBOSE   /* verbose behavior */
/*#define RAT_EXTR*/  /* use rational extrapolation with BS method */
#define ENERGYUNIT 0  /* 0=C15,16 M*, rest E*; 1=all M*; 2=all E* */
/* ====================================================================== */
/* Here yscal[] governing the accuracy can be controlled */
/* ---------------------------------------------------------------------- */
/* "local" -- bound the error of each step individually: */
/* 1: pure fract. (rel.) error (when dep. vars differ enorm. in magnitude) */
/* 2: abs. error (oscillatory f's that pass 0 but bounded by minmaxvals), */
/*    in this case set yscal to those maximum values (see YMAX below) */
/* 3: improved version of 2, abs. error below YMAX, fract. above */
/* ---------------------------------------------------------------------- */
/* "global" -- prevents accumulation of errors throughout integration: */
/* 4: for application sensitive to accumulation of errors, prop. to step */
/* ---------------------------------------------------------------------- */
/* DEFAULT (=0): fract. error except "very" near 0 crossings (depend. vars */
/*   differ enorm.), this is a general-purpose choice combining approaches */
/*   mentioned above; just comment out the YSCAL definition */
#define YSCAL 3
#define YMAX 1.0
/* ====================================================================== */
/* Whether to send on output sigma*(polyx+1)*xi^2 (LOGDLESSDENS 0) */
/* or log_10(sigma*(polyx+1)*xi_1^2) (LOGDLESSDENS 1) */
#define LOGDLESSDENS 0
/* ====================================================================== */
/* Whether to apply adaptive stepsize max cutoff (APPLYMXSAV 1) */
/* or not (APPLYMXSAV 0) */
#define APPLYMXSAV 1
/* ====================================================================== */
/* Here the output format in function spit_out() can be controlled */
#ifdef DBL_PREC
#define OFMT_TRUE  "%5d \
%.5e %.5e %.5f \
%.5f \
%.5e %.5e %.5f \
%.5f \
%.5f %.5e %.5e \
%.5e %.5f \
%.5e %.5e \
%.5e %.5e \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f %.5f \
%.5f %.5f \
%.5e %.5e \
%.5e %.5f %.5f \
%.5e %.5f \
%.5f \
%.5e %.5f \
%.5f %.5f \
%.5f %.5f %.5f \
%.5e %.5e %.5e \
%.5e \
%.5f \
%.5f \
%.5e %.5e \
%.5e %.5e \
%.5f \
%.5f \
%.5f \
%.5f \
%.5e %.5e \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f %.5f %.5f \
%.5f \
%.5f %.5f \
%.5f \
%.5f \
%.6e %.6e %.6e \
%.6e %.6e %.6e %.6e %.6e %.6e\n"
#define OFMT_DLESS "%5d \
%.5f %.5f %.5f \
%.5f \
%.5f %.5f %.5f \
%.5f \
%.5f %.5f %.5f \
%.5f %.5f \
%.5f %.5f \
%.5f %.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f %.5f \
%.5f %.5f \
%.5f %.5f \
%.5f %.5f %.5f \
%.5f %.5f \
%.5f \
%.5f %.5f \
%.5f %.5f \
%.5f %.5f %.5f \
%.5f %.5f %.5f \
%.5f \
%.5f \
%.5f \
%.5f %.5f \
%.5f %.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f %.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f \
%.5f %.5f %.5f \
%.5f \
%.5f %.5f \
%.5f \
%.5f \
%.6e %.6e %.6e \
%.6e %.6e %.6e %.6e %.6e %.6e\n"
#else /* DBL_PREC */
#define OFMT_TRUE  "%5d \
%.4e %.4e %.4f \
%.4f \
%.4e %.4e %.4f \
%.4f \
%.4f %.4e %.4e \
%.4e %.4f \
%.4e %.4e \
%.4e %.4e \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f %.4f \
%.4f %.4f \
%.4e %.4e \
%.4e %.4f %.4f \
%.4e %.4f \
%.4f \
%.4e %.4f \
%.4f %.4f \
%.4f %.4f %.4f \
%.4e %.4e %.4e \
%.4e \
%.4f \
%.4f \
%.4e %.4e \
%.4e %.4e \
%.4f \
%.4f \
%.4f \
%.4f \
%.4e %.4e \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f %.4f %.4f \
%.4f \
%.4f %.4f \
%.4f \
%.4f \
%.5e %.5e %.5e \
%.5e %.5e %.5e %.5e %.5e %.5e\n"
#define OFMT_DLESS "%5d \
%.4f %.4f %.4f \
%.4f \
%.4f %.4f %.4f \
%.4f \
%.4f %.4f %.4f \
%.4f %.4f \
%.4f %.4f \
%.4f %.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f %.4f \
%.4f %.4f \
%.4f %.4f \
%.4f %.4f %.4f \
%.4f %.4f \
%.4f \
%.4f %.4f \
%.4f %.4f \
%.4f %.4f %.4f \
%.4f %.4f %.4f \
%.4f \
%.4f \
%.4f \
%.4f %.4f \
%.4f %.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f %.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f \
%.4f %.4f %.4f \
%.4f \
%.4f %.4f \
%.4f \
%.4f \
%.5e %.5e %.5e \
%.5e %.5e %.5e %.5e %.5e %.5e\n"
#endif /* DBL_PREC */
/* ====================================================================== */
/* </CUSTOMIZATION SECTION> */

/* just sets YSCAL to 0 if undefined */
#ifndef YSCAL /* do _not_ change this and two following lines, please !! */
#define YSCAL 0
#endif

/* functions odeint(), spit_header() */
#ifdef DBL_PREC
#define TINY 1.0e-200  /* tiny but non-zero to prevent division by zero */
#else
#define TINY 1.0e-30   /* ditto */
#endif

/* function polint() */
#define IPOLPTS 4      /* use four-point (i.e., cubic) interpolation */

/* machine epsilon as reported by the routine 'machar' */
#ifdef DBL_PREC
#define MACHEPS 2.3e-16 /* 2.22045e-16 */
#define SMACHEP "2.3E-16"
#else
#define MACHEPS 1.2e-7  /* 1.19209e-07 */
#define SMACHEP "1.2E-7"
#endif

/* mathematical and physical constants */
#ifdef M_PI
#define PI M_PI
#else
#define PI 3.14159265358979323846
#endif
#define FOURPI (4.0*PI)
#define EIGHTPI (8.0*PI)
#define MSOLMANT 1.989
#define CMANT 2.99792458
#define GC2MANT 0.7425
#define EVMANT 1.602

/* zero-antisymmetric power function macro: a generalization of standard */
/* power function pow(x,n) for which negative x is edible in conjunction */
/* with real-type  n */
#define ZAPOW(x,n) (((x)<0.0)?-pow(-(x),(n)):pow((x),(n)))

/* zero-antisymmetric square root macro: a generalization of standard */
/* square root sqrt(x) for which negative x is edible */
#define ZASQRT(x) (((x)<0.0)?-sqrt(-(x)):sqrt(x))

/* plus cut off square root macro: a generalization of standard */
/* square root sqrt(x) for which negative x is cut off to zero */
#define PCOSQRT(x) (((x)<0.0)?0.0:sqrt(x))

/* macro computating covariant component g_{rr} = 1/g^{rr} */
#define G_RR(x,x2,y2,n,s,l) (1./(1.-2.*(s)*((n)+1.)*(((x>0.0)?((y2)/(x)):0.0) +(1./3.)*(l)*(x2))))

/* macro computing frequent expression (1+p/(rho*c^2)) and (n*sigma*theta) */
#define PTORHO1(y1,s) (1.+(s)*(y1))
#define NTORHO1(n,s,y1) ((n)*(s)*(y1))
/* (the latter contributed by Kristina Mrazova) */

/* number of dependent variables (theta,v,xioverbar,e_0,e_0g,zord,zopt) */
/* can be 2, 3, 4, 5, 6, 7 */
#define NVAR 7

/* auxiliary string abbreviations */
#define CCHR '#'       /* comment char (for use with gnuplot) */
#define MNC "#"        /* comment string (for use with gnuplot) */
#define MCHR '!'       /* metacomment char */
#define HMC MNC"! "    /* metacomment string = MNC + (!<->MCHR) + space */
#define HC  MNC"  "    /* comment-out string = MNC + doublespace */
#define IDT1 "  "      /* message indentation */
#define IDT2 "    "    /* message double indentation */

/* RCS buffer items and length per item */
#define RCSITM  6      /* we use 6 items form Id */
#define RCSBUF 64      /* hopefully enough, avoid long filename */

/* command-line buffer */
#define CMDLBUF 256    /* hopefully enough */

/* where to send messages */
#define STDMSG stderr

/* double vs. single precision C preprocessor directives */
#ifdef DBL_PREC
#define PREC "double"
#define FTY double /* we take double precision; Lambda may be too small */
#define FTF "%lf"  /* double precision format for scanf() */
#else
#define PREC "single"
#define FTY float  /* we take single precision; is that sufficient?? */
#define FTF "%f"   /* single precision format for scanf() */
#endif

/* char is sufficient datatype to hold the logical variable */
#define BOOL int

/* external variables (see grp_main.c for description) */
extern FTY polyx,
    sigma,
    lambda,
    coscon,
    rhoc,
    keos,
    xg,
    xfac,
    epsilon,
    dxsav,
    mxsav;
extern int kmax,
    ekmax,
    kount,
    ikount,
    nrhs;
extern BOOL isx;

/* function prototypes */
void rhs_i(const FTY x, FTY y[], FTY dydx[]);
void rhs_e(const FTY x, FTY y[], FTY dydx[]);
void feed_in(void);
void spit_out(const int from, const int to, const BOOL xspit);
int solve_ode(void);
void nrerror(const char error_text[]);
void cry_err_s(const char error_text[], const char what_failed[], int excode);
void cry_err_c(const char error_text[], int what_failed, int excode);
void cry_err_d(const char error_text[], int what_failed, int excode);
void cry_err_f(const char error_text[], FTY what_failed, int excode);

/* number of equations for external solution */
#if NVAR < 3
#define ENVAR 0
#endif
#if NVAR >= 3 && NVAR < 6
#  define ENVAR 1
#endif
#if NVAR == 6
#  define ENVAR 2
#endif
#if NVAR >= 7
#  define ENVAR 3
#endif

#endif /* _GRP_ */
