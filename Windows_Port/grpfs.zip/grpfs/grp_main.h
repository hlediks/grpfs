/*
 * ========================================================================
 * Linux-to-Windows port based on Linux version
 * $Id: grp_main.h,v 3.0 2005/10/07 17:34:57 sta Exp $
 * ------------------------------------------------------------------------
 * This header file contains C preprocessor directives, macros, variable
 * declarations and function prototypes specific for the corresponding
 * *.c module.  Caution: this header file is not self-contained. It will
 * fail unless the shared header file grp.h is included before this one.
 * ========================================================================
 */

#ifndef _GRP_MAIN_
#define _GRP_MAIN_

/* function prototypes */
void spit_header(char rcs[][RCSBUF], char creator[], char *title);
void sweep(void);

#endif /* _GRP_MAIN_ */
