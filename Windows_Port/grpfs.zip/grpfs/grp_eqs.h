/*
 * ========================================================================
 * Linux-to-Windows port based on Linux version
 * $Id: grp_eqs.h,v 3.0 2005/10/07 17:34:57 sta Exp $
 * ------------------------------------------------------------------------
 * This header file contains C preprocessor directives, macros, variable
 * declarations and function prototypes specific for the corresponding
 * *.c module.  Caution: this header file is not self-contained. It will
 * fail unless the shared header file grp.h is included before this one.
 * ========================================================================
 */

#ifndef _GRP_EQS_
#define _GRP_EQS_

/* referencing declaration */
extern int adbmode;
extern FTY *xp,**yp;
extern BOOL method;

#endif /* _GRP_EQS_ */
