/*
 * ========================================================================
 * Linux-to-Windows port based on Linux version
 * $Id: grp_nutl.c,v 3.0 2005/10/07 17:34:57 sta Exp $
 * ------------------------------------------------------------------------
 * This module contains utility functions from nrutil.c including
 * some additions .
 * Based on (C) Copr. 1986-92 Numerical Recipes Software &0&35.
 * ========================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "grp.h"
#include "grp_nutl.h"

void cry_err_s(const char error_text[], const char what_failed[], int excode)
/* General error handler, string variation */
{
    (void)fprintf(STDMSG,"\n"CNAME": %s: %s\n", what_failed, error_text);
    if (excode) exit(excode);  /* 0: no exit, non-0: exit */
}

void cry_err_c(const char error_text[], int what_failed, int excode)
/* General error handler, char variation */
{
    (void)fprintf(STDMSG,"\n"CNAME": %c: %s\n", what_failed, error_text);
    if (excode) exit(excode);  /* 0: no exit, non-0: exit */
}

void cry_err_d(const char error_text[], int what_failed, int excode)
/* General error handler, int variation */
{
    (void)fprintf(STDMSG,"\n"CNAME": %d: %s\n", what_failed, error_text);
    if (excode) exit(excode);  /* 0: no exit, non-0: exit */
}

void cry_err_f(const char error_text[], FTY what_failed, int excode)
/* General error handler, FTY (real floating type) variation */
{
    (void)fprintf(STDMSG,"\n"CNAME": %f: %s\n", what_failed, error_text);
    if (excode) exit(excode);  /* 0: no exit, non-0: exit */
}

void nrerror(const char error_text[])
/* Numerical Recipes standard error handler */
{
    (void)fprintf(STDMSG,"\nNumerical Recipes run-time error:\n\
  %s\nExiting to system.\n",error_text);
    exit(1);
}

FTY *vector(long nl, long nh)
/* allocate a FTY vector with subscript range v[nl..nh] */
{
    FTY *v;

    v=(FTY *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(FTY)));
    if (!v) nrerror("allocation failure in vector()");
    return v-nl+NR_END;
}

FTY **matrix(long nrl, long nrh, long ncl, long nch)
/* allocate a FTY matrix with subscript range m[nrl..nrh][ncl..nch] */
{
    long i, nrow=nrh-nrl+1,ncol=nch-ncl+1;
    FTY **m;

    /* allocate pointers to rows */
    m=(FTY **) malloc((size_t)((nrow+NR_END)*sizeof(FTY*)));
    if (!m) nrerror("allocation failure 1 in matrix()");
    m += NR_END;
    m -= nrl;

    /* allocate rows and set pointers to them */
    m[nrl]=(FTY *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(FTY)));
    if (!m[nrl]) nrerror("allocation failure 2 in matrix()");
    m[nrl] += NR_END;
    m[nrl] -= ncl;

    for(i=nrl+1;i<=nrh;i++) m[i]=m[i-1]+ncol;

    /* return pointer to array of pointers to rows */
    return m;
}

void free_vector(FTY *v, long nl, long nh)
/* free a FTY vector allocated with dvector() */
{
    nh=nl; /* dirty trick just to make gcc with -W option happy */
    free((FREE_ARG) (v+nl-NR_END));
}

void free_matrix(FTY **m, long nrl, long nrh, long ncl, long nch)
/* free a FTY matrix allocated by matrix() */
{
    nrh=nrl, nch=ncl; /* dirty trick just to make gcc with -W option happy */
    free((FREE_ARG) (m[nrl]+ncl-NR_END));
    free((FREE_ARG) (m+nrl-NR_END));
}
