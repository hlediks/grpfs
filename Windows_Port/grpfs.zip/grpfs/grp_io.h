/*
 * ========================================================================
 * Linux-to-Windows port based on Linux version
 * $Id: grp_io.h,v 3.0 2005/10/07 17:34:57 sta Exp $
 * ------------------------------------------------------------------------
 * This header file contains C preprocessor directives, macros, variable
 * declarations and function prototypes specific for the corresponding
 * *.c module.  Caution: this header file is not self-contained. It will
 * fail unless the shared header file grp.h is included before this one.
 * ========================================================================
 */

#ifndef _GRP_IO_
#define _GRP_IO_

/* separator length */
#define SEPLNG 64

/* "magic char": the char that "magic string" starts with */
#define MAGCHR "M"

/* "magic string" maxlen */
#define MAGMAX 16  /* there could be some whitespace before magic string */

/* function spit_out() */
#define PAD 0.0

/* functions feed_in() and spit_header() */
#define RHOCUNIT "10^5g/cm^3"   /* unit string for central mass density */
#define EKMAX_MIN 4             /* minimum value of ekmax */

/* function spit_header() */
#define LENUNIT "10^4 km"
#define MASSUNIT "solar mass"
#define ENERUNIT "10^55 erg"
#define DENSUNIT RHOCUNIT
#define EDNYUNIT "eV/fm^3"
#define PRESUNIT "10^27 dyn/cm^2"
#define LAMBUNIT "cm^-2"
#define KUNIT "cm^{2+3/n} g^{-1/n} s^{-2}"

/* referencing declaration */
extern BOOL method,iact,iscc;
extern FTY *xp,**yp;                         /* in function spit_out() */
extern struct {   /* characteristic scales */
    BOOL true;
    FTY lngt;
    FTY mass;
    FTY ergy;
    FTY dnty;
    FTY edny;
    FTY prse;
} skal;
extern int adbmode;

/* function prototypes */
void ask_int_value(int *val,const char *vdesc, const int vleg, const int vlim);
void ask_real_value(FTY *val,const char *vdesc,const int vleg,const FTY vlim1,const FTY vlim2,const char *ffm);
void print_separator(const int seplen);
void spit_header(char rcs[][RCSBUF], char creator[], char *title);
void print_smiley(const char *chs);
void meta_gobble(void);
void accept_real(const char *fm, const FTY val);
void accept_int(const int val);
void check_magic(void);
void sweep(void);
void print_retry(void);

#endif /* _GRP_IO_ */
