#ifndef _CCOPT_
#define _CCOPT_
const char *ccflg="-std=c99 -pedantic -Werror -Wall -Wmissing-prototypes -Wstrict-prototypes -Wshadow -Wpointer-arith -Wcast-qual -Wcast-align -Wwrite-strings -Wnested-externs -fshort-enums -fno-common -Dinline= -O4 $(ADD_FLAGS)";
const char *ccopt="-DDBL_PREC -Wconversion -DENERGYUNIT=0";
const char *ccver="gcc version 4.2.1 (SUSE Linux)";
const char *ccdat="Wed Oct  9 21:31:24 CEST 2013";
const char *ccusr="lvs";
const char *cchst="gemini.loewenet";
const char *ccip="127.0.0.2";
const char *ccunm="Linux 2.6.22.19-0.4-default #1 SMP 2009-08-14 02:09:16 +0200 i686";
const char *ccdir="/home/lvs/Pool/projects/code/grpfs";
#endif /* _CCOPT_ */
