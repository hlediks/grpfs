/*
 * ========================================================================
 * $Id: grp_eqs.c,v 3.0 2005/10/07 17:34:57 sta Exp $
 * Revision log is at the end of file.
 * ------------------------------------------------------------------------
 * This module contains functions rhs_i, rhs_e that evaluate
 * the right-hand side(s) of canonically-shaped differential
 * equations
 *   dy_i/dx = F_i(x,y_1,...,y_NVAR),  i = 1,...,NVAR,ENVAR.
 * The calculated values are pushed to the array dydx[] that
 * is the last argument of the function void rhs_i, rhs_e.
 * ========================================================================
 */

#include <math.h>
#include "grp.h"
#include "grp_eqs.h"

void rhs_i(const FTY x, FTY y[], FTY dydx[])
/* Evaluates the right-hand side of ODEs governing internal solution. */
{
    FTY xsq=x*x, /* auxiliary variable to save three squarings */
	grr=G_RR(x,xsq,y[2],polyx,sigma,lambda),     /* similar */
	ptorh1=PTORHO1(y[1],sigma),                  /* polytropic */
	ntorh1=NTORHO1(polyx,sigma,y[1]);            /* adiabatic */

#ifdef DBL_PREC
    FTY thetan=ZAPOW(y[1],polyx); /* aux. variable to save one pow() call */
#if NVAR >= 3
    FTY grrsqrt=ZASQRT(grr);      /* similar */
#endif
#else /* DBL_PREC */
    /* don't rely on implicit cast, guy */
    FTY thetan=(float)ZAPOW((double)(y[1]),(double)polyx);
#if NVAR >= 3
    FTY grrsqrt=(float)ZASQRT((double)grr);  /* similar */
#endif
#endif /* DBL_PREC */

#if NVAR >= 7
    FTY optemp; /* temp variable for calculating optical embs */
#endif

    nrhs++; /* just counts function evaluations; top-level variable */

    /* index 1 corresponds to theta, i.e., "mass density"  */
    /* (caution -- this right-hand side must be defined separately */
    /* for x positive and for x zero to aviod division by zero): */
    if (adbmode) /* adiabatic */
	dydx[1] = x>0.0 ? \
	    -((ptorh1+ntorh1)*(y[2]+(sigma*thetan*y[1]-(2./3.)*lambda)*xsq*x)*grr)/xsq:0.0;
    else /* polytropic */
	dydx[1] = x>0.0 ? \
	    -(ptorh1*(y[2]+(sigma*thetan*y[1]-(2./3.)*lambda)*xsq*x)*grr)/xsq:0.0;

    /* index 2 corresponds to v, i.e., "mass inside r": */
    if (adbmode) /* adiabatic */
	dydx[2] = xsq*thetan*(1.+ntorh1);
    else /* polytropic */
	dydx[2] = xsq*thetan;

#if NVAR >= 3
    /* index 3 corresponds to "proper radius" xi with overbar */
    dydx[3] = grrsqrt;

#if NVAR >= 4
    /* index 4 corresponds to "proper energy" e_0 */
    dydx[4] = dydx[2]*dydx[3];

#if NVAR >= 5
    /* index 5 corresponds to "proper rest energy" e_0g */
    if (adbmode) /* adiabatic */
	dydx[5] = xsq*thetan*dydx[3];
    else /* polytropic */
	dydx[5] = dydx[4]/ZAPOW(ptorh1,polyx);

#if NVAR >= 6
    /* index 6 corresponds to ordinary embedding diagram z axis */
    dydx[6] = ZASQRT(grr - 1.0);

#if NVAR >= 7
    /* index 7 corresponds to optical embedding diagram z axis */
    optemp = ptorh1+sigma*(polyx+1.0)*x*dydx[1];
    dydx[7] = ZAPOW(ptorh1,polyx)*PCOSQRT(ptorh1*ptorh1*grr-optemp*optemp);

#endif /* NVAR >= 7 */
#endif /* NVAR >= 6 */
#endif /* NVAR >= 5 */
#endif /* NVAR >= 4 */
#endif /* NVAR >= 3 */
}

#if NVAR >= 3
void rhs_e(const FTY x, FTY y[], FTY dydx[])
/* Evaluates the right-hand side of ODEs governing external solution. */
{
    FTY xsq=x*x, /* auxiliary variable to save squarings */
	grr,     /* metric coefficient */
	tmp;     /* temp variable */
    FTY zz; zz = y[1]; /* just to make gcc with fussy options happy */

    if (method) { /* adaptive stepsize */
	grr=G_RR(x,xsq,yp[2][ikount+ekmax+1],polyx,sigma,lambda); /* v1 !! */
	tmp=1.0-3.0*sigma*(polyx+1.0)*yp[2][ikount+ekmax+1]/x;
	/* the 2 lines above cannot use y[2][1] (see grp_node.c) because */
	/* that element is currently in use (grp_node.c rewrites it after */
	/* this function is called via ODE solver */
    }
    else { /* fixed stepsize */
	grr=G_RR(x,xsq,yp[2][kmax+ekmax+2],polyx,sigma,lambda); /* v1 !! */
	tmp=1.0-3.0*sigma*(polyx+1.0)*yp[2][kmax+ekmax+2]/x;
	/* the 2 lines above cannot use y[2][1] (see grp_node.c) because */
	/* that element is currently in use (grp_node.c rewrites it after */
	/* this function is called via ODE solver */
    }

    nrhs++; /* just counts function evaluations; top-level variable */

#if ENVAR >= 1
    /* index 1 corresponds to "proper radius" xi with overbar */
#ifdef DBL_PREC
    dydx[1] = ZASQRT(grr);
#else /* DBL_PREC */
    dydx[1] = (float)ZASQRT((double)grr);
#endif /* DBL_PREC */

#if ENVAR >= 2
    /* index 2 corresponds to ordinary embedding diagram z axis */
#ifdef DBL_PREC
    dydx[2] = ZASQRT(grr - 1.0);
#else /* DBL_PREC */
    dydx[2] = (float)ZASQRT((double)grr - 1.0);
#endif /* DBL_PREC */

#if ENVAR >= 3
    /* index 3 corresponds to optical embedding diagram z axis */
#ifdef DBL_PREC
    dydx[3] = grr*ZASQRT(1.0-tmp*tmp*grr);
#else /* DBL_PREC */
    dydx[3] = (float)grr*ZASQRT(1.0-(double)tmp*tmp*grr);
#endif /* DBL_PREC */

#endif /* NVAR >= 3 */
#endif /* NVAR >= 2 */
#endif /* NVAR >= 1 */
}
#endif

/*
 * $Log: grp_eqs.c,v $
 * Revision 3.0  2005/10/07 17:34:57  sta
 * Starting revision
 *
 * Revision 2.1  2003/02/05 18:25:51  sta
 * external extension added
 *
 * Revision 2.0  2003/01/30 20:24:26  sta
 * principal, full fledged revision
 *
 * Revision 1.3  2002-02-08 19:53:11+01  rag
 * Maintenance revision.
 *
 * Revision 1.2  2002-02-05 21:21:32+01  rag
 * Maintenance
 *
 * Revision 1.1  2001/10/02 10:44:44  rag
 * Initial revision
 *
 */
