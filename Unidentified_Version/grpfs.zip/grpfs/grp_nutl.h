/*
 * ========================================================================
 * $Id: grp_nutl.h,v 3.0 2005/10/07 17:34:57 sta Exp $
 * Revision log is at the end of file.
 * ------------------------------------------------------------------------
 * This header file contains C preprocessor directives, macros, variable
 * declarations and function prototypes specific for the corresponding
 * *.c module.  Caution: this header file is not self-contained. It will
 * fail unless the shared header file grp.h is included before this one.
 * ========================================================================
 */

#ifndef _GRP_NUTL_
#define _GRP_NUTL_

/* Numerical Recipes utilities C preprocessor definitions */
#define NR_END 1
#define FREE_ARG char*

/* function prototypes */
FTY *vector(long nl, long nh);
FTY **matrix(long nrl, long nrh, long ncl, long nch);
void free_vector(FTY *v, long nl, long nh);
void free_matrix(FTY **m, long nrl, long nrh, long ncl, long nch);

#endif /* _GRP_NUTL_ */

/*
 * $Log: grp_nutl.h,v $
 * Revision 3.0  2005/10/07 17:34:57  sta
 * Starting revision
 *
 * Revision 2.0  2003/01/30 20:24:26  sta
 * principal, full fledged revision
 *
 * Revision 1.2  2002-02-05 21:21:32+01  rag
 * Maintenance
 *
 * Revision 1.1  2001/10/02 10:54:19  rag
 * Initial revision
 *
 */
