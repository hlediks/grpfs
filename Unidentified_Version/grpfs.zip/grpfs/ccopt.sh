#!/bin/bash

cat <<EOF >ccopt.h
#ifndef _CCOPT_
#define _CCOPT_
const char *ccflg="`grep "^CFLAGS" Makefile | cut -d '=' -f 2- | colrm 1 1`";
const char *ccopt="`grep "^ADD_FLAGS" Makefile | cut -d '=' -f 2- | colrm 1 1`";
const char *ccver="`gcc -v 2>&1 | tail --lines 1`";
const char *ccdat="`date`";
const char *ccusr="`whoami`";
const char *cchst="`hostname --fqdn`";
const char *ccip="`hostname -i`";
const char *ccunm="`uname -srmv`";
const char *ccdir="`pwd`";
#endif /* _CCOPT_ */
EOF
